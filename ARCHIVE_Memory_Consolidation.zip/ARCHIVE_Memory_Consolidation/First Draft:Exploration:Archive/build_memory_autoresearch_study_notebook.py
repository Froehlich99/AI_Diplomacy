from __future__ import annotations

import json
import textwrap
from pathlib import Path


NOTEBOOK_PATH = Path(__file__).with_name("memory_autoresearch_full_study.ipynb")


def md(text: str) -> dict:
    cleaned = textwrap.dedent(text).strip("\n")
    return {
        "cell_type": "markdown",
        "metadata": {},
        "source": cleaned.splitlines(keepends=True),
    }


def code(text: str) -> dict:
    cleaned = textwrap.dedent(text).strip("\n")
    return {
        "cell_type": "code",
        "execution_count": None,
        "metadata": {},
        "outputs": [],
        "source": cleaned.splitlines(keepends=True),
    }


cells = [
    md(
        """
        # Memory Autoresearch Study Notebook

        This notebook is a mixed-methods analysis workspace for the Diplomacy memory-autoresearch runs. It is designed to:

        - statistically compare variants across stages and families,
        - correlate protocol metrics and diary structure with outcomes,
        - inspect failure modes from logs and review packets,
        - compare control variants (`V0`, `V1`) against structured variants,
        - support optional OpenRouter-powered qualitative analysis of diary summaries and failure cases.

        The notebook assumes the repository contains the completed `mem-v2`, `mem-v5`, and auxiliary control artifacts that were generated during the experiment campaigns.
        """
    ),
    code(
        """
        from pathlib import Path
        import os
        import sys
        import json

        import numpy as np
        import pandas as pd
        import seaborn as sns
        import matplotlib.pyplot as plt
        from IPython.display import Markdown, display

        ROOT = Path.cwd().resolve()
        if not (ROOT / "memory_autoresearch.py").exists():
            ROOT = ROOT.parent.resolve()

        ANALYSIS_DIR = ROOT / "analysis"
        RESULTS_DIR = ROOT / "results" / "autoresearch"
        CACHE_DIR = ANALYSIS_DIR / "notebook_cache" / "openrouter"

        if str(ANALYSIS_DIR) not in sys.path:
            sys.path.insert(0, str(ANALYSIS_DIR))

        import memory_autoresearch_notebook_utils as mau

        pd.set_option("display.max_columns", 120)
        pd.set_option("display.max_colwidth", 160)
        sns.set_theme(style="whitegrid", context="talk")
        """
    ),
    md(
        """
        ## Methodological framing

        This notebook uses a deliberately layered methodology:

        1. **Protocol-level quantitative analysis** of the experiment outputs (`stage_summary.json`, `results.tsv`, `leaderboard.tsv`, agent-memory snapshots, and run logs).
        2. **Diary-structure analysis** over consolidated summaries and manual-review packets.
        3. **Failure-mode analysis** using protocol metrics, warning/error signatures, and optional prior judge outputs.
        4. **LLM-assisted qualitative analysis** using structured rubrics and mirrored pairwise comparison.

        Statistical choices are intentionally conservative:

        - **BCa bootstrap intervals** for small samples,
        - **permutation tests** instead of assuming normality,
        - **Spearman rank correlation** for monotonic associations,
        - **mixed methods** for diary/failure analysis rather than pretending everything can be reduced to one scalar.

        The OpenRouter cells are optional and cached. They are meant for qualitative evidence and comparative interpretation, not for replacing the protocol metrics.
        """
    ),
    code(
        """
        methodology_sources = mau.methodology_sources_frame()
        display(methodology_sources)
        """
    ),
    code(
        """
        run_registry = mau.default_run_registry(ROOT)
        aggregates_df, leaderboard_df = mau.load_run_registry_stage_tables(run_registry)
        game_df = mau.load_run_registry_game_rows(run_registry)
        memory_df = mau.load_run_registry_agent_memories(run_registry)
        review_df = mau.load_run_registry_manual_reviews(run_registry)
        log_df = mau.load_run_registry_logs(run_registry)
        precomputed_exports = mau.load_optional_memory_metric_exports(ROOT)

        judge_error_df = precomputed_exports.get("llm_judge_memory_error_analysis", pd.DataFrame()).copy()
        combined_variant_metrics_df = precomputed_exports.get("combined_variant_metrics", pd.DataFrame()).copy()
        outcomes_game_df = precomputed_exports.get("outcomes_game_level", pd.DataFrame()).copy()
        outcomes_power_df = precomputed_exports.get("outcomes_power_level", pd.DataFrame()).copy()

        print(f"Registered runs: {len(run_registry)}")
        print(f"Stage aggregate rows: {len(aggregates_df)}")
        print(f"Power-level memory rows: {len(memory_df)}")
        print(f"Manual review packets: {len(review_df)}")
        print(f"Log rows: {len(log_df)}")
        print(f"Optional precomputed exports: {sorted(precomputed_exports)}")
        """
    ),
    code(
        """
        display(run_registry)
        display(mau.variant_metadata_frame())

        artifact_summary = pd.DataFrame(
            [
                {"artifact": "stage aggregates", "rows": len(aggregates_df)},
                {"artifact": "leaderboard rows", "rows": len(leaderboard_df)},
                {"artifact": "game rows", "rows": len(game_df)},
                {"artifact": "power-level memory rows", "rows": len(memory_df)},
                {"artifact": "manual review packets", "rows": len(review_df)},
                {"artifact": "game logs", "rows": len(log_df)},
            ]
        )
        display(artifact_summary)
        """
    ),
    md(
        """
        ## 1. Variant comparison at the protocol level

        We start from the authoritative stage summaries. This is the cleanest view of what the experiments themselves recorded:

        - `mean_final_sc`
        - `survival_rate`
        - `retention_score`
        - `contradiction_rate`
        - `parse_failure_rate`
        - `order_success_rate`
        - `total_cost_usd`

        The tables below are the main protocol readout before we descend into diaries and qualitative failure analysis.
        """
    ),
    code(
        """
        protocol_metrics = [
            "mean_final_sc",
            "survival_rate",
            "retention_score",
            "contradiction_rate",
            "parse_failure_rate",
            "order_success_rate",
            "total_cost_usd",
        ]

        mem_v2_snapshot = mau.stage_metric_snapshot(aggregates_df, protocol_metrics, run_label="mem-v2")
        mem_v5_snapshot = mau.stage_metric_snapshot(aggregates_df, protocol_metrics, run_label="mem-v5-final")

        display(Markdown("### `mem-v2` protocol snapshot"))
        display(mem_v2_snapshot.sort_values(["stage", "variant_id"]).reset_index(drop=True))

        display(Markdown("### Final `mem-v5` protocol snapshot"))
        display(mem_v5_snapshot.sort_values(["stage", "variant_id"]).reset_index(drop=True))
        """
    ),
    code(
        """
        focus_variants = [
            "V0_no_memory",
            "V2_baseline_freeform",
            "V3_structured_consolidation",
            "V4_importance_aware",
            "V5_base",
            "V5_unresolved_bias",
        ]

        plot_df = aggregates_df[
            aggregates_df["variant_id"].isin(focus_variants)
            & aggregates_df["run_label"].isin(["mem-v2", "mem-v5-final"])
        ].copy()

        fig, axes = plt.subplots(2, 3, figsize=(22, 12), constrained_layout=True)
        metric_grid = [
            "mean_final_sc",
            "survival_rate",
            "retention_score",
            "contradiction_rate",
            "parse_failure_rate",
            "order_success_rate",
        ]

        for ax, metric in zip(axes.ravel(), metric_grid):
            sns.barplot(
                data=plot_df,
                x="variant_id",
                y=metric,
                hue="stage",
                ax=ax,
            )
            ax.set_title(metric)
            ax.tick_params(axis="x", rotation=35)
            if metric != metric_grid[0]:
                ax.legend_.remove()

        axes[0, 0].legend(title="stage", bbox_to_anchor=(1.02, 1.0), loc="upper left")
        plt.show()
        """
    ),
    md(
        """
        ## 2. Small-sample uncertainty and pairwise comparisons

        The experiment summaries aggregate over relatively few games. For that reason, the notebook works at the **power-level outcome layer** whenever possible and uses:

        - **bootstrap confidence intervals** for the mean final supply-center count,
        - **permutation tests** for pairwise comparisons,
        - paired comparisons only when the matching structure is defensible.

        This section is especially useful for checking how much confidence we should place in observed deltas.
        """
    ),
    code(
        """
        authoritative_memory = memory_df[
            memory_df["run_label"].isin(["mem-v2", "mem-v5-final", "mem-v5-v0-cross-model"])
        ].copy()

        ci_rows = []
        for (run_label, stage, variant_id), group in authoritative_memory.groupby(["run_label", "stage", "variant_id"]):
            stats = mau.bootstrap_mean_ci(group["final_supply_center_count"])
            ci_rows.append(
                {
                    "run_label": run_label,
                    "stage": stage,
                    "variant_id": variant_id,
                    **stats,
                }
            )

        ci_df = pd.DataFrame(ci_rows).sort_values(["run_label", "stage", "variant_id"]).reset_index(drop=True)
        display(ci_df)

        fig, ax = plt.subplots(figsize=(16, 6))
        ci_plot = ci_df.copy()
        ci_plot["label"] = ci_plot["run_label"] + " | " + ci_plot["stage"] + " | " + ci_plot["variant_id"]
        ax.errorbar(
            x=np.arange(len(ci_plot)),
            y=ci_plot["mean"],
            yerr=[
                ci_plot["mean"] - ci_plot["ci_low"],
                ci_plot["ci_high"] - ci_plot["mean"],
            ],
            fmt="o",
            capsize=4,
        )
        ax.set_xticks(np.arange(len(ci_plot)))
        ax.set_xticklabels(ci_plot["label"], rotation=65, ha="right")
        ax.set_ylabel("Mean final SC (bootstrap CI)")
        ax.set_title("Power-level final supply-center estimates with BCa bootstrap intervals")
        plt.show()
        """
    ),
    code(
        """
        paired_mem_v2 = mau.pairwise_variant_table(
            authoritative_memory,
            metric="final_supply_center_count",
            variant_pairs=[("V3_structured_consolidation", "V2_baseline_freeform")],
            group_filter={"run_label": "mem-v2", "stage": "cross_model"},
            paired_on=["run_label", "stage", "game_key", "power_name"],
        )

        paired_mem_v5 = mau.pairwise_variant_table(
            authoritative_memory,
            metric="final_supply_center_count",
            variant_pairs=[("V5_base", "V3_structured_consolidation")],
            group_filter={"run_label": "mem-v5-final", "stage": "cross_model"},
            paired_on=["run_label", "stage", "game_key", "power_name"],
        )

        strong_model_controls = authoritative_memory[
            (authoritative_memory["stage"] == "cross_model")
            & authoritative_memory["variant_id"].isin(["V0_no_memory", "V2_baseline_freeform", "V3_structured_consolidation", "V5_base"])
        ].copy()

        control_compare = mau.pairwise_variant_table(
            strong_model_controls,
            metric="final_supply_center_count",
            variant_pairs=[
                ("V2_baseline_freeform", "V0_no_memory"),
                ("V3_structured_consolidation", "V0_no_memory"),
                ("V5_base", "V0_no_memory"),
            ],
        )

        display(Markdown("### Paired comparison: `V3` vs `V2` in `mem-v2` cross-model"))
        display(paired_mem_v2)

        display(Markdown("### Paired comparison: `V5_base` vs `V3` in final `mem-v5` cross-model"))
        display(paired_mem_v5)

        display(Markdown("### Strong-model controls including standalone `V0` cross-model"))
        display(control_compare)
        """
    ),
    md(
        """
        ## 3. Correlating outcomes with diary structure

        To connect results back to the memory artifacts themselves, we analyze the final consolidated diaries saved in `agent_memories/*.json`.

        The features below are deliberately simple and interpretable:

        - diary length (`text_words`, `text_chars`)
        - number of headings and bullets
        - distinct power mentions
        - status-tag usage
        - duplicate-line fraction
        - trust/relationship summaries

        These are not meant to be the final word on causal mechanisms. They are a first-pass way to study whether particular memory characteristics co-vary with final outcomes.
        """
    ),
    code(
        """
        corr_features = [
            "text_words",
            "text_chars",
            "heading_count",
            "bullet_count",
            "distinct_power_mentions",
            "power_mention_count",
            "status_tag_count",
            "duplicate_line_fraction",
            "goal_count",
            "mean_trust",
            "std_trust",
            "n_positive_relationships",
            "n_negative_relationships",
        ]

        corr_sc = mau.spearman_screen(authoritative_memory, "final_supply_center_count", corr_features)
        corr_survival = mau.spearman_screen(
            authoritative_memory.assign(survived_int=authoritative_memory["survived"].astype(float)),
            "survived_int",
            corr_features,
        )

        display(Markdown("### Spearman screen vs final supply centers"))
        display(corr_sc)

        display(Markdown("### Spearman screen vs survival"))
        display(corr_survival)
        """
    ),
    code(
        """
        fig, axes = plt.subplots(1, 2, figsize=(18, 6), constrained_layout=True)

        sns.scatterplot(
            data=authoritative_memory,
            x="text_words",
            y="final_supply_center_count",
            hue="variant_id",
            style="run_label",
            ax=axes[0],
        )
        axes[0].set_title("Diary length vs final supply centers")

        sns.scatterplot(
            data=authoritative_memory,
            x="duplicate_line_fraction",
            y="final_supply_center_count",
            hue="variant_id",
            style="run_label",
            ax=axes[1],
        )
        axes[1].set_title("Duplicate-line fraction vs final supply centers")

        plt.show()
        """
    ),
    md(
        """
        ## 4. Manual review queue: compression, retention, and structure

        The manual review packets are the most direct source for studying what the consolidation step actually did.

        Each packet contains:

        - the older diary source text,
        - the retained recent entries,
        - the consolidated summary text,
        - stage / game / phase / power metadata.

        This section lets us compare compression behavior, power/entity retention, and structure by variant family.
        """
    ),
    code(
        """
        review_focus = review_df[
            review_df["variant_id"].isin(
                [
                    "V2_baseline_freeform",
                    "V3_structured_consolidation",
                    "V4_importance_aware",
                    "V5_base",
                    "V5_unresolved_bias",
                ]
            )
        ].copy()

        review_summary = (
            review_focus.groupby(["run_label", "stage", "variant_id"])[
                [
                    "compression_ratio",
                    "power_retention_ratio",
                    "summary_words",
                    "summary_status_tag_count",
                    "summary_heading_count",
                    "summary_duplicate_line_fraction",
                ]
            ]
            .mean()
            .round(3)
            .reset_index()
        )
        display(review_summary)

        fig, ax = plt.subplots(figsize=(10, 7))
        sns.scatterplot(
            data=review_focus,
            x="compression_ratio",
            y="power_retention_ratio",
            hue="variant_id",
            style="stage",
            alpha=0.8,
            ax=ax,
        )
        ax.set_title("Compression vs retained power/entity signal")
        plt.show()
        """
    ),
    code(
        """
        representative_packets = mau.choose_representative_review_packets(
            review_focus,
            variants=["V2_baseline_freeform", "V3_structured_consolidation", "V5_base"],
            sort_by="power_retention_ratio",
            ascending=False,
            top_k=1,
        ).copy()

        representative_packets["summary_preview"] = representative_packets["consolidated_summary_text"].str.slice(0, 700)
        representative_packets["source_preview"] = representative_packets["source_older_diary_text"].str.slice(0, 400)

        display(
            representative_packets[
                [
                    "variant_id",
                    "stage",
                    "phase",
                    "power",
                    "compression_ratio",
                    "power_retention_ratio",
                    "summary_status_tag_count",
                    "summary_preview",
                ]
            ]
        )
        """
    ),
    md(
        """
        ## 5. Failure modes from protocol metrics, logs, and prior judge outputs

        Failure analysis is intentionally triangulated. We look at:

        - protocol failure metrics (`parse_failure_rate`, `contradiction_rate`, `invalid_order_rate`),
        - log signatures (`WARNING`, `ERROR`, JSON parse fallback, timeouts, order rejections),
        - optional prior qualitative judge outputs if they exist in `memory_metrics_outputs`.
        """
    ),
    code(
        """
        risk_table = aggregates_df[
            [
                "run_label",
                "stage",
                "variant_id",
                "retention_score",
                "contradiction_rate",
                "parse_failure_rate",
                "invalid_order_rate",
                "order_success_rate",
                "mean_final_sc",
            ]
        ].sort_values(["run_label", "stage", "variant_id"]).reset_index(drop=True)
        display(risk_table)

        log_summary = (
            log_df.groupby(["run_label", "stage", "variant_id"])[
                [
                    "warning_count",
                    "error_count",
                    "json_fallback_count",
                    "resume_count",
                    "order_rejected_count",
                    "timeout_count",
                ]
            ]
            .mean()
            .round(2)
            .reset_index()
        )
        display(log_summary)
        """
    ),
    code(
        """
        if not combined_variant_metrics_df.empty:
            behavior_proxy_cols = [
                "variant_id",
                "runs",
                "avg_bounce_rate",
                "avg_hard_failed_rate",
                "avg_disrupted_rate",
                "avg_commitment_adherence_proxy",
                "avg_support_accuracy_proxy",
                "avg_memory_to_order_alignment_proxy",
                "betrayal_stickiness_2phase",
                "enemy_targeting_consistency",
            ]
            display(Markdown("### Optional behavior proxies from prior analysis exports"))
            display(combined_variant_metrics_df[behavior_proxy_cols].sort_values("variant_id").reset_index(drop=True))
        else:
            print("No `combined_variant_metrics.csv` export found; skipping behavior proxies.")
        """
    ),
    code(
        """
        if not judge_error_df.empty:
            display(Markdown("### Prior LLM judge outputs (loaded from `memory_metrics_outputs`)"))
            effect_by_variant = judge_error_df.groupby(["variant_id", "memory_effect_label"]).size().unstack(fill_value=0)
            collapse_by_variant = judge_error_df.groupby(["variant_id", "collapse_type"]).size().unstack(fill_value=0)
            main_failures = (
                judge_error_df.groupby(["variant_id", "main_failure"])
                .size()
                .reset_index(name="count")
                .sort_values(["variant_id", "count"], ascending=[True, False])
            )
            display(effect_by_variant)
            display(collapse_by_variant)
            display(main_failures.groupby("variant_id", group_keys=False).head(5))
        else:
            print("No prior LLM judge CSV found; skipping this subsection.")
        """
    ),
    md(
        """
        ## 6. Optional OpenRouter qualitative analysis

        This final section is optional. If `OPENROUTER_API_KEY` is present, the notebook can run:

        - **pointwise qualitative rating** of memory packets, and
        - **mirrored pairwise comparisons** to reduce position bias when comparing variants.

        Suggested default workflow:

        1. rate a handful of representative packets pointwise,
        2. compare `V3` vs `V2`,
        3. compare accepted `V5_base` vs `V3`,
        4. inspect disagreements between forward and reversed order.
        """
    ),
    code(
        """
        LLM_MODEL = os.getenv("OPENROUTER_NOTEBOOK_MODEL", "openai/gpt-4.1-mini")
        OPENROUTER_READY = mau.openrouter_available()
        RUN_OPENROUTER_ANALYSIS = os.getenv("RUN_OPENROUTER_ANALYSIS", "").strip().lower() in {"1", "true", "yes"}

        llm_packet_candidates = representative_packets.copy()
        display(llm_packet_candidates[["variant_id", "stage", "phase", "power", "compression_ratio", "power_retention_ratio"]])

        print(f"OpenRouter ready: {OPENROUTER_READY}")
        print(f"Run OpenRouter analysis now: {RUN_OPENROUTER_ANALYSIS}")
        print(f"Judge model: {LLM_MODEL}")
        print(f"Cache dir: {CACHE_DIR}")
        """
    ),
    code(
        """
        if RUN_OPENROUTER_ANALYSIS and OPENROUTER_READY and not llm_packet_candidates.empty:
            pointwise_rows = []
            for _, row in llm_packet_candidates.iterrows():
                packet = mau.review_packet_for_llm(row)
                result = mau.llm_rate_review_packet(
                    packet,
                    model=LLM_MODEL,
                    cache_dir=CACHE_DIR / "pointwise",
                )
                pointwise_rows.append(
                    {
                        "variant_id": row["variant_id"],
                        "stage": row["stage"],
                        "phase": row["phase"],
                        "power": row["power"],
                        **result,
                    }
                )
            pointwise_df = pd.DataFrame(pointwise_rows)
            display(pointwise_df)
        else:
            print("Skipping live qualitative analysis. Set RUN_OPENROUTER_ANALYSIS=1 (and OPENROUTER_API_KEY) to enable it.")
        """
    ),
    code(
        """
        if RUN_OPENROUTER_ANALYSIS and OPENROUTER_READY:
            pair_rows = []
            pair_specs = [
                ("V3_structured_consolidation", "V2_baseline_freeform"),
                ("V5_base", "V3_structured_consolidation"),
            ]

            for left_variant, right_variant in pair_specs:
                left_rows = llm_packet_candidates[llm_packet_candidates["variant_id"] == left_variant]
                right_rows = llm_packet_candidates[llm_packet_candidates["variant_id"] == right_variant]
                if left_rows.empty or right_rows.empty:
                    continue

                left_packet = mau.review_packet_for_llm(left_rows.iloc[0])
                right_packet = mau.review_packet_for_llm(right_rows.iloc[0])
                verdict = mau.llm_compare_review_packets(
                    left_packet,
                    right_packet,
                    model=LLM_MODEL,
                    cache_dir=CACHE_DIR / "pairwise",
                    mirrored=True,
                )
                pair_rows.append(
                    {
                        "left_variant": left_variant,
                        "right_variant": right_variant,
                        "winner_consensus": verdict.get("winner_consensus"),
                        "faithfulness_consensus": verdict.get("faithfulness_winner_consensus"),
                        "salience_consensus": verdict.get("salience_winner_consensus"),
                        "actionability_consensus": verdict.get("actionability_winner_consensus"),
                        "freshness_consensus": verdict.get("freshness_winner_consensus"),
                        "robustness_consensus": verdict.get("robustness_winner_consensus"),
                        "raw_verdict": json.dumps(verdict, ensure_ascii=False)[:1200],
                    }
                )

            if pair_rows:
                display(pd.DataFrame(pair_rows))
            else:
                print("No pairwise packet pairs were available in the sampled representatives.")
        else:
            print("Skipping live pairwise comparison. Set RUN_OPENROUTER_ANALYSIS=1 (and OPENROUTER_API_KEY) to enable it.")
        """
    ),
    md(
        """
        ## 7. Practical extensions

        Natural next steps for this notebook:

        - add a dedicated **hard-pruning** ablation layer,
        - score **phase-local** memory artifacts rather than only final consolidated diaries,
        - compare **same-power same-phase** packets across variants where a tighter pairing is available,
        - export notebook tables to a paper-ready appendix.
        """
    ),
]


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {
            "display_name": "Python 3",
            "language": "python",
            "name": "python3",
        },
        "language_info": {
            "name": "python",
            "version": "3.11",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}


NOTEBOOK_PATH.write_text(json.dumps(notebook, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"Wrote {NOTEBOOK_PATH}")
