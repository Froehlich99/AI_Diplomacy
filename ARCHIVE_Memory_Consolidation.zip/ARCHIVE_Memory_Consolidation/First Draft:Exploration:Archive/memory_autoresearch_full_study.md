# Memory Autoresearch Study Notebook

This notebook is a mixed-methods analysis workspace for the Diplomacy memory-autoresearch runs. It is designed to:

- statistically compare variants across stages and families,
- correlate protocol metrics and diary structure with outcomes,
- inspect failure modes from logs and review packets,
- compare control variants (`V0`, `V1`) against structured variants,
- support optional OpenRouter-powered qualitative analysis of diary summaries and failure cases.

The notebook assumes the repository contains the completed `mem-v2`, `mem-v5`, and auxiliary control artifacts that were generated during the experiment campaigns.


```python
from pathlib import Path
import os
import sys
import json
import importlib
importlib.reload(mau)
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from IPython.display import Markdown, display

ROOT = Path.cwd().resolve()
if not (ROOT / "memory_autoresearch.py").exists():
    ROOT = ROOT.parent.resolve()

ANALYSIS_DIR = ROOT / "analysis"
RESULTS_DIR = ROOT / "results" / "autoresearch"
CACHE_DIR = ANALYSIS_DIR / "notebook_cache" / "openrouter"

if str(ANALYSIS_DIR) not in sys.path:
    sys.path.insert(0, str(ANALYSIS_DIR))

import memory_autoresearch_notebook_utils as mau

pd.set_option("display.max_columns", 120)
pd.set_option("display.max_colwidth", 160)
sns.set_theme(style="whitegrid", context="talk")
```

## Methodological framing

This notebook uses a deliberately layered methodology:

1. **Protocol-level quantitative analysis** of the experiment outputs (`stage_summary.json`, `results.tsv`, `leaderboard.tsv`, agent-memory snapshots, and run logs).
2. **Diary-structure analysis** over consolidated summaries and manual-review packets.
3. **Failure-mode analysis** using protocol metrics, warning/error signatures, and optional prior judge outputs.
4. **LLM-assisted qualitative analysis** using structured rubrics and mirrored pairwise comparison.

Statistical choices are intentionally conservative:

- **BCa bootstrap intervals** for small samples,
- **permutation tests** instead of assuming normality,
- **Spearman rank correlation** for monotonic associations,
- **mixed methods** for diary/failure analysis rather than pretending everything can be reduced to one scalar.

The OpenRouter cells are optional and cached. They are meant for qualitative evidence and comparative interpretation, not for replacing the protocol metrics.


```python
methodology_sources = mau.methodology_sources_frame()
display(methodology_sources)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>topic</th>
      <th>source</th>
      <th>url</th>
      <th>note</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bootstrap confidence intervals</td>
      <td>SciPy bootstrap docs</td>
      <td>https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html</td>
      <td>BCa intervals are a good default for small and skewed samples.</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Permutation tests</td>
      <td>SciPy permutation_test docs</td>
      <td>https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.permutation_test.html</td>
      <td>Useful when sample sizes are small and parametric assumptions are weak.</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Spearman rank correlation</td>
      <td>SciPy spearmanr docs</td>
      <td>https://docs.scipy.org/doc/scipy-1.15.1/reference/generated/scipy.stats.spearmanr.html</td>
      <td>Nonparametric monotonic association; SciPy warns p-values are only accurate for large samples.</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LLM form-filling evaluation</td>
      <td>G-Eval (OpenReview)</td>
      <td>https://openreview.net/forum?id=puMfaHb1hY</td>
      <td>Motivates structured rubrics and form-filling for LLM-based qualitative evaluation.</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Bias checks for LLM-as-judge</td>
      <td>Pairwise meta-evaluator paper</td>
      <td>https://www.mdpi.com/2078-2489/16/8/652</td>
      <td>Supports mirrored pairwise comparisons to diagnose order and evaluator instability.</td>
    </tr>
    <tr>
      <th>5</th>
      <td>OpenRouter API support</td>
      <td>OpenRouter chat completion docs</td>
      <td>https://openrouter.ai/docs/api-reference/chat-completion</td>
      <td>Documents the chat-completions endpoint used for optional notebook-side qualitative analysis.</td>
    </tr>
  </tbody>
</table>
</div>



```python
run_registry = mau.default_run_registry(ROOT)
aggregates_df, leaderboard_df = mau.load_run_registry_stage_tables(run_registry)
game_df = mau.load_run_registry_game_rows(run_registry)
memory_df = mau.load_run_registry_agent_memories(run_registry)
review_df = mau.load_run_registry_manual_reviews(run_registry)
log_df = mau.load_run_registry_logs(run_registry)
precomputed_exports = mau.load_optional_memory_metric_exports(ROOT)

judge_error_df = precomputed_exports.get("llm_judge_memory_error_analysis", pd.DataFrame()).copy()
combined_variant_metrics_df = precomputed_exports.get("combined_variant_metrics", pd.DataFrame()).copy()
outcomes_game_df = precomputed_exports.get("outcomes_game_level", pd.DataFrame()).copy()
outcomes_power_df = precomputed_exports.get("outcomes_power_level", pd.DataFrame()).copy()

print(f"Registered runs: {len(run_registry)}")
print(f"Stage aggregate rows: {len(aggregates_df)}")
print(f"Power-level memory rows: {len(memory_df)}")
print(f"Manual review packets: {len(review_df)}")
print(f"Log rows: {len(log_df)}")
print(f"Optional precomputed exports: {sorted(precomputed_exports)}")
```

    Registered runs: 8
    Stage aggregate rows: 88
    Power-level memory rows: 1246
    Manual review packets: 811
    Log rows: 179
    Optional precomputed exports: ['alliance_persistence', 'alliance_reciprocity', 'betrayal_enemy_targeting', 'bounce_failed_metrics', 'combined_variant_metrics', 'combined_variant_metrics_with_llm_judge', 'commitment_adherence', 'llm_judge_memory_error_analysis', 'memory_to_order_alignment', 'opportunism_metrics', 'orders_parsed', 'outcomes_game_level', 'outcomes_power_level', 'per_power_variant_advantage', 'variant_outcome_summary']



```python
display(run_registry)
display(mau.variant_metadata_frame())

artifact_summary = pd.DataFrame(
    [
        {"artifact": "stage aggregates", "rows": len(aggregates_df)},
        {"artifact": "leaderboard rows", "rows": len(leaderboard_df)},
        {"artifact": "game rows", "rows": len(game_df)},
        {"artifact": "power-level memory rows", "rows": len(memory_df)},
        {"artifact": "manual review packets", "rows": len(review_df)},
        {"artifact": "game logs", "rows": len(log_df)},
    ]
)
display(artifact_summary)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>run_root</th>
      <th>cohort</th>
      <th>authority</th>
      <th>include_by_default</th>
      <th>notes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v2</td>
      <td>baseline-benchmark</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Main V0-V4 benchmark with V3 as final pre-V5 incumbent.</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v5-v0-cross-model</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__v0_cross_model_grok</td>
      <td>control</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Standalone V0 no-memory Grok cross-model control.</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v5-final</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase2_phase1_v5_03</td>
      <td>v5-family</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Authoritative final V5 family run; V5_base defeats V3 in cross-model.</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v5-phase2-exploratory</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase2</td>
      <td>v5-family</td>
      <td>exploratory</td>
      <td>False</td>
      <td>Exploratory branch retained for archival comparison only.</td>
    </tr>
    <tr>
      <th>4</th>
      <td>phase1_v5_00</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase1_v5_00</td>
      <td>v5-phase1-search</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Phase-1 V5 mutation-search candidate run.</td>
    </tr>
    <tr>
      <th>5</th>
      <td>phase1_v5_01</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase1_v5_01</td>
      <td>v5-phase1-search</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Phase-1 V5 mutation-search candidate run.</td>
    </tr>
    <tr>
      <th>6</th>
      <td>phase1_v5_02</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase1_v5_02</td>
      <td>v5-phase1-search</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Phase-1 V5 mutation-search candidate run.</td>
    </tr>
    <tr>
      <th>7</th>
      <td>phase1_v5_03</td>
      <td>/Users/anatolelobenko/Downloads/AI_Diplomacy-main/results/autoresearch/mem-v5-20260424__phase1_v5_03</td>
      <td>v5-phase1-search</td>
      <td>authoritative</td>
      <td>True</td>
      <td>Phase-1 V5 mutation-search candidate run.</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variant_id</th>
      <th>family</th>
      <th>memory_mode</th>
      <th>description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>V0_no_memory</td>
      <td>control</td>
      <td>no prompt-visible memory</td>
      <td>Private diary exists for logging but is not re-injected into later prompts.</td>
    </tr>
    <tr>
      <th>1</th>
      <td>V1_raw_verbatim_window</td>
      <td>control</td>
      <td>raw recency window</td>
      <td>Retains recent diary text verbatim without consolidation.</td>
    </tr>
    <tr>
      <th>2</th>
      <td>V2_baseline_freeform</td>
      <td>baseline</td>
      <td>year plus freeform summary</td>
      <td>Baseline freeform summary of older history with one recent year kept verbatim.</td>
    </tr>
    <tr>
      <th>3</th>
      <td>V3_structured_consolidation</td>
      <td>structured</td>
      <td>fixed semantic headings</td>
      <td>Same budget as V2 but uses fixed structured headings for consolidation.</td>
    </tr>
    <tr>
      <th>4</th>
      <td>V4_importance_aware</td>
      <td>structured</td>
      <td>importance-aware retention</td>
      <td>Structured consolidation plus salience-aware carry-forward of unresolved facts.</td>
    </tr>
    <tr>
      <th>5</th>
      <td>V5_change_aware_structured</td>
      <td>v5-search</td>
      <td>change-aware schema</td>
      <td>Initial V5 candidate with explicit stable-vs-reversal sections.</td>
    </tr>
    <tr>
      <th>6</th>
      <td>V5_mutation_01</td>
      <td>v5-search</td>
      <td>change-aware schema mutation 1</td>
      <td>Merged redundant sections and increased betrayal emphasis.</td>
    </tr>
    <tr>
      <th>7</th>
      <td>V5_mutation_02</td>
      <td>v5-search</td>
      <td>change-aware schema mutation 2</td>
      <td>Exact headings plus event citations and stronger unit specificity.</td>
    </tr>
    <tr>
      <th>8</th>
      <td>V5_mutation_03</td>
      <td>v5-search</td>
      <td>change-aware schema mutation 3</td>
      <td>Clarified active vs broken commitments and tightened schema rules.</td>
    </tr>
    <tr>
      <th>9</th>
      <td>V5_base</td>
      <td>v5-family</td>
      <td>accepted V5 schema</td>
      <td>Final accepted V5 structure with the base V3-equivalent budget split.</td>
    </tr>
    <tr>
      <th>10</th>
      <td>V5_recent2</td>
      <td>v5-family</td>
      <td>accepted V5 schema, recency-heavy</td>
      <td>Two recent years kept verbatim with a smaller older-history block.</td>
    </tr>
    <tr>
      <th>11</th>
      <td>V5_history_heavy</td>
      <td>v5-family</td>
      <td>accepted V5 schema, history-heavy</td>
      <td>Larger budget allocated to consolidated older history.</td>
    </tr>
    <tr>
      <th>12</th>
      <td>V5_unresolved_bias</td>
      <td>v5-family</td>
      <td>accepted V5 schema, unresolved-first</td>
      <td>Prioritizes unresolved commitments and betrayals over completed plans.</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>artifact</th>
      <th>rows</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>stage aggregates</td>
      <td>88</td>
    </tr>
    <tr>
      <th>1</th>
      <td>leaderboard rows</td>
      <td>88</td>
    </tr>
    <tr>
      <th>2</th>
      <td>game rows</td>
      <td>175</td>
    </tr>
    <tr>
      <th>3</th>
      <td>power-level memory rows</td>
      <td>1246</td>
    </tr>
    <tr>
      <th>4</th>
      <td>manual review packets</td>
      <td>811</td>
    </tr>
    <tr>
      <th>5</th>
      <td>game logs</td>
      <td>179</td>
    </tr>
  </tbody>
</table>
</div>


## 1. Variant comparison at the protocol level

We start from the authoritative stage summaries. This is the cleanest view of what the experiments themselves recorded:

- `mean_final_sc`
- `survival_rate`
- `retention_score`
- `contradiction_rate`
- `parse_failure_rate`
- `order_success_rate`
- `total_cost_usd`

The tables below are the main protocol readout before we descend into diaries and qualitative failure analysis.


```python
protocol_metrics = [
    "mean_final_sc",
    "survival_rate",
    "retention_score",
    "contradiction_rate",
    "parse_failure_rate",
    "order_success_rate",
    "total_cost_usd",
]

mem_v2_snapshot = mau.stage_metric_snapshot(aggregates_df, protocol_metrics, run_label="mem-v2")
mem_v5_snapshot = mau.stage_metric_snapshot(aggregates_df, protocol_metrics, run_label="mem-v5-final")

display(Markdown("### `mem-v2` protocol snapshot"))
display(mem_v2_snapshot.sort_values(["stage", "variant_id"]).reset_index(drop=True))

display(Markdown("### Final `mem-v5` protocol snapshot"))
display(mem_v5_snapshot.sort_values(["stage", "variant_id"]).reset_index(drop=True))
```


### `mem-v2` protocol snapshot



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>mean_final_sc</th>
      <th>survival_rate</th>
      <th>retention_score</th>
      <th>contradiction_rate</th>
      <th>parse_failure_rate</th>
      <th>order_success_rate</th>
      <th>total_cost_usd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V2_baseline_freeform</td>
      <td>4.380952</td>
      <td>1.000000</td>
      <td>0.876822</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.593607</td>
      <td>0.616114</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>4.333333</td>
      <td>1.000000</td>
      <td>0.969307</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.587385</td>
      <td>0.630096</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V4_importance_aware</td>
      <td>4.428571</td>
      <td>1.000000</td>
      <td>0.959329</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.615509</td>
      <td>0.640895</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V2_baseline_freeform</td>
      <td>4.857143</td>
      <td>0.857143</td>
      <td>0.908294</td>
      <td>0.021470</td>
      <td>0.000000</td>
      <td>0.686991</td>
      <td>2.076605</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>4.857143</td>
      <td>0.857143</td>
      <td>0.938164</td>
      <td>0.032994</td>
      <td>0.000000</td>
      <td>0.650870</td>
      <td>1.987081</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V0_no_memory</td>
      <td>3.857143</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.601990</td>
      <td>0.058787</td>
    </tr>
    <tr>
      <th>6</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V1_raw_verbatim_window</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.624390</td>
      <td>0.068353</td>
    </tr>
    <tr>
      <th>7</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V2_baseline_freeform</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>0.891837</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.672043</td>
      <td>0.069492</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V3_structured_consolidation</td>
      <td>4.142857</td>
      <td>1.000000</td>
      <td>0.960204</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.649485</td>
      <td>0.069032</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V4_importance_aware</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>0.972007</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.572193</td>
      <td>0.070221</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V0_no_memory</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.018519</td>
      <td>0.591742</td>
      <td>0.195033</td>
    </tr>
    <tr>
      <th>11</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V1_raw_verbatim_window</td>
      <td>4.500000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.001587</td>
      <td>0.000000</td>
      <td>0.601437</td>
      <td>0.241263</td>
    </tr>
    <tr>
      <th>12</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V2_baseline_freeform</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.870408</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.584967</td>
      <td>0.243975</td>
    </tr>
    <tr>
      <th>13</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.961501</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.625941</td>
      <td>0.253793</td>
    </tr>
    <tr>
      <th>14</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V4_importance_aware</td>
      <td>4.214286</td>
      <td>1.000000</td>
      <td>0.966922</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.646574</td>
      <td>0.248898</td>
    </tr>
  </tbody>
</table>
</div>



### Final `mem-v5` protocol snapshot



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>mean_final_sc</th>
      <th>survival_rate</th>
      <th>retention_score</th>
      <th>contradiction_rate</th>
      <th>parse_failure_rate</th>
      <th>order_success_rate</th>
      <th>total_cost_usd</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>4.428571</td>
      <td>1.000000</td>
      <td>0.966533</td>
      <td>0.002834</td>
      <td>0.000000</td>
      <td>0.618841</td>
      <td>0.643829</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V5_base</td>
      <td>4.619048</td>
      <td>1.000000</td>
      <td>0.982877</td>
      <td>0.001323</td>
      <td>0.003663</td>
      <td>0.642738</td>
      <td>0.635210</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V5_unresolved_bias</td>
      <td>4.476190</td>
      <td>1.000000</td>
      <td>0.979887</td>
      <td>0.000000</td>
      <td>0.008547</td>
      <td>0.568779</td>
      <td>0.635881</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v5-final</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>4.857143</td>
      <td>0.857143</td>
      <td>0.942422</td>
      <td>0.014041</td>
      <td>0.029070</td>
      <td>0.672457</td>
      <td>1.975053</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v5-final</td>
      <td>cross_model</td>
      <td>V5_base</td>
      <td>4.857143</td>
      <td>0.928571</td>
      <td>0.979383</td>
      <td>0.006692</td>
      <td>0.000000</td>
      <td>0.628636</td>
      <td>2.082412</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V3_structured_consolidation</td>
      <td>4.000000</td>
      <td>1.000000</td>
      <td>0.969116</td>
      <td>0.000000</td>
      <td>0.071429</td>
      <td>0.625000</td>
      <td>0.065490</td>
    </tr>
    <tr>
      <th>6</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_base</td>
      <td>3.857143</td>
      <td>1.000000</td>
      <td>0.978146</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.682292</td>
      <td>0.073022</td>
    </tr>
    <tr>
      <th>7</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_history_heavy</td>
      <td>3.857143</td>
      <td>1.000000</td>
      <td>0.962755</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.678363</td>
      <td>0.068938</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_recent2</td>
      <td>4.142857</td>
      <td>1.000000</td>
      <td>0.957143</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.531250</td>
      <td>0.069986</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_unresolved_bias</td>
      <td>3.714286</td>
      <td>1.000000</td>
      <td>0.977041</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.621762</td>
      <td>0.070947</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.972428</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.646469</td>
      <td>0.250043</td>
    </tr>
    <tr>
      <th>11</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_base</td>
      <td>4.214286</td>
      <td>1.000000</td>
      <td>0.976977</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.583945</td>
      <td>0.252459</td>
    </tr>
    <tr>
      <th>12</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_history_heavy</td>
      <td>3.714286</td>
      <td>1.000000</td>
      <td>0.483155</td>
      <td>0.000000</td>
      <td>0.794643</td>
      <td>0.879678</td>
      <td>0.042092</td>
    </tr>
    <tr>
      <th>13</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_recent2</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.971723</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.587088</td>
      <td>0.248805</td>
    </tr>
    <tr>
      <th>14</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_unresolved_bias</td>
      <td>4.357143</td>
      <td>1.000000</td>
      <td>0.972606</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.647483</td>
      <td>0.248568</td>
    </tr>
  </tbody>
</table>
</div>



```python
focus_variants = [
    "V0_no_memory",
    "V2_baseline_freeform",
    "V3_structured_consolidation",
    "V4_importance_aware",
    "V5_base",
    "V5_unresolved_bias",
]

plot_df = aggregates_df[
    aggregates_df["variant_id"].isin(focus_variants)
    & aggregates_df["run_label"].isin(["mem-v2", "mem-v5-final"])
].copy()

fig, axes = plt.subplots(2, 3, figsize=(22, 12), constrained_layout=True)
metric_grid = [
    "mean_final_sc",
    "survival_rate",
    "retention_score",
    "contradiction_rate",
    "parse_failure_rate",
    "order_success_rate",
]

for ax, metric in zip(axes.ravel(), metric_grid):
    sns.barplot(
        data=plot_df,
        x="variant_id",
        y=metric,
        hue="stage",
        ax=ax,
    )
    ax.set_title(metric)
    ax.tick_params(axis="x", rotation=35)
    if metric != metric_grid[0]:
        ax.legend_.remove()

axes[0, 0].legend(title="stage", bbox_to_anchor=(1.02, 1.0), loc="upper left")
plt.show()
```


    
![png](memory_autoresearch_full_study_files/memory_autoresearch_full_study_8_0.png)
    


## 2. Small-sample uncertainty and pairwise comparisons

The experiment summaries aggregate over relatively few games. For that reason, the notebook works at the **power-level outcome layer** whenever possible and uses:

- **bootstrap confidence intervals** for the mean final supply-center count,
- **permutation tests** for pairwise comparisons,
- paired comparisons only when the matching structure is defensible.

This section is especially useful for checking how much confidence we should place in observed deltas.


```python
authoritative_memory = memory_df[
    memory_df["run_label"].isin(["mem-v2", "mem-v5-final", "mem-v5-v0-cross-model"])
].copy()

ci_rows = []
for (run_label, stage, variant_id), group in authoritative_memory.groupby(["run_label", "stage", "variant_id"]):
    stats = mau.bootstrap_mean_ci(group["final_supply_center_count"])
    ci_rows.append(
        {
            "run_label": run_label,
            "stage": stage,
            "variant_id": variant_id,
            **stats,
        }
    )

ci_df = pd.DataFrame(ci_rows).sort_values(["run_label", "stage", "variant_id"]).reset_index(drop=True)
display(ci_df)

fig, ax = plt.subplots(figsize=(16, 6))
ci_plot = ci_df.copy()
ci_plot["label"] = ci_plot["run_label"] + " | " + ci_plot["stage"] + " | " + ci_plot["variant_id"]
ax.errorbar(
    x=np.arange(len(ci_plot)),
    y=ci_plot["mean"],
    yerr=[
        ci_plot["mean"] - ci_plot["ci_low"],
        ci_plot["ci_high"] - ci_plot["mean"],
    ],
    fmt="o",
    capsize=4,
)
ax.set_xticks(np.arange(len(ci_plot)))
ax.set_xticklabels(ci_plot["label"], rotation=65, ha="right")
ax.set_ylabel("Mean final SC (bootstrap CI)")
ax.set_title("Power-level final supply-center estimates with BCa bootstrap intervals")
plt.show()
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>n</th>
      <th>mean</th>
      <th>ci_low</th>
      <th>ci_high</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V2_baseline_freeform</td>
      <td>21</td>
      <td>4.380952</td>
      <td>3.761905</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>21</td>
      <td>4.333333</td>
      <td>3.476190</td>
      <td>5.285714</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V4_importance_aware</td>
      <td>21</td>
      <td>4.428571</td>
      <td>3.666667</td>
      <td>5.285714</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V2_baseline_freeform</td>
      <td>14</td>
      <td>4.857143</td>
      <td>3.428571</td>
      <td>6.214286</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>14</td>
      <td>4.857143</td>
      <td>3.214286</td>
      <td>6.428571</td>
    </tr>
    <tr>
      <th>5</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V0_no_memory</td>
      <td>7</td>
      <td>3.857143</td>
      <td>3.000000</td>
      <td>4.571429</td>
    </tr>
    <tr>
      <th>6</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V1_raw_verbatim_window</td>
      <td>7</td>
      <td>4.000000</td>
      <td>3.285714</td>
      <td>4.714286</td>
    </tr>
    <tr>
      <th>7</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V2_baseline_freeform</td>
      <td>7</td>
      <td>4.000000</td>
      <td>3.285714</td>
      <td>4.714286</td>
    </tr>
    <tr>
      <th>8</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V3_structured_consolidation</td>
      <td>7</td>
      <td>4.142857</td>
      <td>3.428571</td>
      <td>4.714286</td>
    </tr>
    <tr>
      <th>9</th>
      <td>mem-v2</td>
      <td>sanity</td>
      <td>V4_importance_aware</td>
      <td>7</td>
      <td>4.000000</td>
      <td>3.428571</td>
      <td>4.857143</td>
    </tr>
    <tr>
      <th>10</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V0_no_memory</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.857143</td>
      <td>5.071429</td>
    </tr>
    <tr>
      <th>11</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V1_raw_verbatim_window</td>
      <td>14</td>
      <td>4.500000</td>
      <td>3.714286</td>
      <td>5.071429</td>
    </tr>
    <tr>
      <th>12</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V2_baseline_freeform</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.500000</td>
      <td>4.928571</td>
    </tr>
    <tr>
      <th>13</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.428571</td>
      <td>5.357143</td>
    </tr>
    <tr>
      <th>14</th>
      <td>mem-v2</td>
      <td>screening</td>
      <td>V4_importance_aware</td>
      <td>14</td>
      <td>4.214286</td>
      <td>3.785714</td>
      <td>4.642857</td>
    </tr>
    <tr>
      <th>15</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>21</td>
      <td>4.428571</td>
      <td>3.761905</td>
      <td>5.095238</td>
    </tr>
    <tr>
      <th>16</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V5_base</td>
      <td>21</td>
      <td>4.619048</td>
      <td>3.952381</td>
      <td>5.428571</td>
    </tr>
    <tr>
      <th>17</th>
      <td>mem-v5-final</td>
      <td>confirmation</td>
      <td>V5_unresolved_bias</td>
      <td>21</td>
      <td>4.476190</td>
      <td>3.809524</td>
      <td>5.095238</td>
    </tr>
    <tr>
      <th>18</th>
      <td>mem-v5-final</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>14</td>
      <td>4.857143</td>
      <td>3.142857</td>
      <td>6.357143</td>
    </tr>
    <tr>
      <th>19</th>
      <td>mem-v5-final</td>
      <td>cross_model</td>
      <td>V5_base</td>
      <td>14</td>
      <td>4.857143</td>
      <td>3.500000</td>
      <td>6.428571</td>
    </tr>
    <tr>
      <th>20</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V3_structured_consolidation</td>
      <td>7</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>5.142857</td>
    </tr>
    <tr>
      <th>21</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_base</td>
      <td>7</td>
      <td>3.857143</td>
      <td>3.285714</td>
      <td>4.428571</td>
    </tr>
    <tr>
      <th>22</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_history_heavy</td>
      <td>7</td>
      <td>3.857143</td>
      <td>3.428571</td>
      <td>4.285714</td>
    </tr>
    <tr>
      <th>23</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_recent2</td>
      <td>7</td>
      <td>4.142857</td>
      <td>3.428571</td>
      <td>5.000000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>mem-v5-final</td>
      <td>sanity</td>
      <td>V5_unresolved_bias</td>
      <td>7</td>
      <td>3.714286</td>
      <td>3.285714</td>
      <td>4.285714</td>
    </tr>
    <tr>
      <th>25</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.857143</td>
      <td>4.857143</td>
    </tr>
    <tr>
      <th>26</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_base</td>
      <td>14</td>
      <td>4.214286</td>
      <td>3.571429</td>
      <td>4.857143</td>
    </tr>
    <tr>
      <th>27</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_history_heavy</td>
      <td>14</td>
      <td>3.714286</td>
      <td>3.357143</td>
      <td>4.214286</td>
    </tr>
    <tr>
      <th>28</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_recent2</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.714286</td>
      <td>5.071429</td>
    </tr>
    <tr>
      <th>29</th>
      <td>mem-v5-final</td>
      <td>screening</td>
      <td>V5_unresolved_bias</td>
      <td>14</td>
      <td>4.357143</td>
      <td>3.571429</td>
      <td>5.357143</td>
    </tr>
    <tr>
      <th>30</th>
      <td>mem-v5-v0-cross-model</td>
      <td>cross_model</td>
      <td>V0_no_memory</td>
      <td>21</td>
      <td>4.809524</td>
      <td>3.619048</td>
      <td>5.809524</td>
    </tr>
  </tbody>
</table>
</div>



    
![png](memory_autoresearch_full_study_files/memory_autoresearch_full_study_10_1.png)
    



```python
paired_mem_v2 = mau.pairwise_variant_table(
    authoritative_memory,
    metric="final_supply_center_count",
    variant_pairs=[("V3_structured_consolidation", "V2_baseline_freeform")],
    group_filter={"run_label": "mem-v2", "stage": "cross_model"},
    paired_on=["run_label", "stage", "game_key", "power_name"],
)

paired_mem_v5 = mau.pairwise_variant_table(
    authoritative_memory,
    metric="final_supply_center_count",
    variant_pairs=[("V5_base", "V3_structured_consolidation")],
    group_filter={"run_label": "mem-v5-final", "stage": "cross_model"},
    paired_on=["run_label", "stage", "game_key", "power_name"],
)

strong_model_controls = authoritative_memory[
    (authoritative_memory["stage"] == "cross_model")
    & authoritative_memory["variant_id"].isin(["V0_no_memory", "V2_baseline_freeform", "V3_structured_consolidation", "V5_base"])
].copy()

control_compare = mau.pairwise_variant_table(
    strong_model_controls,
    metric="final_supply_center_count",
    variant_pairs=[
        ("V2_baseline_freeform", "V0_no_memory"),
        ("V3_structured_consolidation", "V0_no_memory"),
        ("V5_base", "V0_no_memory"),
    ],
)

display(Markdown("### Paired comparison: `V3` vs `V2` in `mem-v2` cross-model"))
display(paired_mem_v2)

display(Markdown("### Paired comparison: `V5_base` vs `V3` in final `mem-v5` cross-model"))
display(paired_mem_v5)

display(Markdown("### Strong-model controls including standalone `V0` cross-model"))
display(control_compare)
```


### Paired comparison: `V3` vs `V2` in `mem-v2` cross-model



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>metric</th>
      <th>left_variant</th>
      <th>right_variant</th>
      <th>delta_mean_left_minus_right</th>
      <th>pvalue</th>
      <th>paired_test</th>
      <th>n_left</th>
      <th>n_right</th>
      <th>n_effective_pairs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>final_supply_center_count</td>
      <td>V3_structured_consolidation</td>
      <td>V2_baseline_freeform</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>True</td>
      <td>14</td>
      <td>14</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>



### Paired comparison: `V5_base` vs `V3` in final `mem-v5` cross-model



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>metric</th>
      <th>left_variant</th>
      <th>right_variant</th>
      <th>delta_mean_left_minus_right</th>
      <th>pvalue</th>
      <th>paired_test</th>
      <th>n_left</th>
      <th>n_right</th>
      <th>n_effective_pairs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>final_supply_center_count</td>
      <td>V5_base</td>
      <td>V3_structured_consolidation</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>True</td>
      <td>14</td>
      <td>14</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>



### Strong-model controls including standalone `V0` cross-model



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>metric</th>
      <th>left_variant</th>
      <th>right_variant</th>
      <th>delta_mean_left_minus_right</th>
      <th>pvalue</th>
      <th>paired_test</th>
      <th>n_left</th>
      <th>n_right</th>
      <th>n_effective_pairs</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>final_supply_center_count</td>
      <td>V2_baseline_freeform</td>
      <td>V0_no_memory</td>
      <td>0.047619</td>
      <td>1.0000</td>
      <td>False</td>
      <td>14</td>
      <td>21</td>
      <td>14</td>
    </tr>
    <tr>
      <th>1</th>
      <td>final_supply_center_count</td>
      <td>V3_structured_consolidation</td>
      <td>V0_no_memory</td>
      <td>0.047619</td>
      <td>0.9928</td>
      <td>False</td>
      <td>28</td>
      <td>21</td>
      <td>21</td>
    </tr>
    <tr>
      <th>2</th>
      <td>final_supply_center_count</td>
      <td>V5_base</td>
      <td>V0_no_memory</td>
      <td>0.047619</td>
      <td>0.9994</td>
      <td>False</td>
      <td>14</td>
      <td>21</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
</div>


## 3. Correlating outcomes with diary structure

To connect results back to the memory artifacts themselves, we analyze the final consolidated diaries saved in `agent_memories/*.json`.

The features below are deliberately simple and interpretable:

- diary length (`text_words`, `text_chars`)
- number of headings and bullets
- distinct power mentions
- status-tag usage
- duplicate-line fraction
- trust/relationship summaries

These are not meant to be the final word on causal mechanisms. They are a first-pass way to study whether particular memory characteristics co-vary with final outcomes.


```python
corr_features = [
    "text_words",
    "text_chars",
    "heading_count",
    "bullet_count",
    "distinct_power_mentions",
    "power_mention_count",
    "status_tag_count",
    "duplicate_line_fraction",
    "goal_count",
    "mean_trust",
    "std_trust",
    "n_positive_relationships",
    "n_negative_relationships",
]

corr_sc = mau.spearman_screen(authoritative_memory, "final_supply_center_count", corr_features)
corr_survival = mau.spearman_screen(
    authoritative_memory.assign(survived_int=authoritative_memory["survived"].astype(float)),
    "survived_int",
    corr_features,
)

display(Markdown("### Spearman screen vs final supply centers"))
display(corr_sc)

display(Markdown("### Spearman screen vs survival"))
display(corr_survival)
```


### Spearman screen vs final supply centers



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature</th>
      <th>n</th>
      <th>rho</th>
      <th>pvalue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>std_trust</td>
      <td>413</td>
      <td>0.114844</td>
      <td>0.019566</td>
    </tr>
    <tr>
      <th>1</th>
      <td>text_words</td>
      <td>413</td>
      <td>0.109103</td>
      <td>0.026614</td>
    </tr>
    <tr>
      <th>2</th>
      <td>bullet_count</td>
      <td>413</td>
      <td>0.026312</td>
      <td>0.593894</td>
    </tr>
    <tr>
      <th>3</th>
      <td>heading_count</td>
      <td>413</td>
      <td>-0.008104</td>
      <td>0.869575</td>
    </tr>
    <tr>
      <th>4</th>
      <td>distinct_power_mentions</td>
      <td>413</td>
      <td>-0.014927</td>
      <td>0.762316</td>
    </tr>
    <tr>
      <th>5</th>
      <td>status_tag_count</td>
      <td>413</td>
      <td>-0.039719</td>
      <td>0.420784</td>
    </tr>
    <tr>
      <th>6</th>
      <td>text_chars</td>
      <td>413</td>
      <td>-0.051804</td>
      <td>0.293581</td>
    </tr>
    <tr>
      <th>7</th>
      <td>duplicate_line_fraction</td>
      <td>413</td>
      <td>-0.069696</td>
      <td>0.157416</td>
    </tr>
    <tr>
      <th>8</th>
      <td>n_negative_relationships</td>
      <td>413</td>
      <td>-0.073932</td>
      <td>0.133621</td>
    </tr>
    <tr>
      <th>9</th>
      <td>goal_count</td>
      <td>413</td>
      <td>-0.081908</td>
      <td>0.096448</td>
    </tr>
    <tr>
      <th>10</th>
      <td>power_mention_count</td>
      <td>413</td>
      <td>-0.083015</td>
      <td>0.092015</td>
    </tr>
    <tr>
      <th>11</th>
      <td>n_positive_relationships</td>
      <td>413</td>
      <td>-0.098052</td>
      <td>0.046435</td>
    </tr>
    <tr>
      <th>12</th>
      <td>mean_trust</td>
      <td>413</td>
      <td>-0.111447</td>
      <td>0.023509</td>
    </tr>
  </tbody>
</table>
</div>



### Spearman screen vs survival



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>feature</th>
      <th>n</th>
      <th>rho</th>
      <th>pvalue</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mean_trust</td>
      <td>413</td>
      <td>0.178872</td>
      <td>0.000259</td>
    </tr>
    <tr>
      <th>1</th>
      <td>goal_count</td>
      <td>413</td>
      <td>0.144515</td>
      <td>0.003246</td>
    </tr>
    <tr>
      <th>2</th>
      <td>distinct_power_mentions</td>
      <td>413</td>
      <td>0.109729</td>
      <td>0.025751</td>
    </tr>
    <tr>
      <th>3</th>
      <td>n_positive_relationships</td>
      <td>413</td>
      <td>0.089950</td>
      <td>0.067826</td>
    </tr>
    <tr>
      <th>4</th>
      <td>status_tag_count</td>
      <td>413</td>
      <td>0.078527</td>
      <td>0.111050</td>
    </tr>
    <tr>
      <th>5</th>
      <td>power_mention_count</td>
      <td>413</td>
      <td>0.069978</td>
      <td>0.155741</td>
    </tr>
    <tr>
      <th>6</th>
      <td>n_negative_relationships</td>
      <td>413</td>
      <td>0.056606</td>
      <td>0.251052</td>
    </tr>
    <tr>
      <th>7</th>
      <td>bullet_count</td>
      <td>413</td>
      <td>0.028393</td>
      <td>0.565028</td>
    </tr>
    <tr>
      <th>8</th>
      <td>duplicate_line_fraction</td>
      <td>413</td>
      <td>0.023510</td>
      <td>0.633798</td>
    </tr>
    <tr>
      <th>9</th>
      <td>heading_count</td>
      <td>413</td>
      <td>0.022139</td>
      <td>0.653709</td>
    </tr>
    <tr>
      <th>10</th>
      <td>text_chars</td>
      <td>413</td>
      <td>-0.099756</td>
      <td>0.042745</td>
    </tr>
    <tr>
      <th>11</th>
      <td>std_trust</td>
      <td>413</td>
      <td>-0.135106</td>
      <td>0.005960</td>
    </tr>
    <tr>
      <th>12</th>
      <td>text_words</td>
      <td>413</td>
      <td>-0.201262</td>
      <td>0.000038</td>
    </tr>
  </tbody>
</table>
</div>



```python
fig, axes = plt.subplots(1, 2, figsize=(18, 6), constrained_layout=True)

sns.scatterplot(
    data=authoritative_memory,
    x="text_words",
    y="final_supply_center_count",
    hue="variant_id",
    style="run_label",
    ax=axes[0],
)
axes[0].set_title("Diary length vs final supply centers")

sns.scatterplot(
    data=authoritative_memory,
    x="duplicate_line_fraction",
    y="final_supply_center_count",
    hue="variant_id",
    style="run_label",
    ax=axes[1],
)
axes[1].set_title("Duplicate-line fraction vs final supply centers")

plt.show()
```


    
![png](memory_autoresearch_full_study_files/memory_autoresearch_full_study_14_0.png)
    


## 4. Manual review queue: compression, retention, and structure

The manual review packets are the most direct source for studying what the consolidation step actually did.

Each packet contains:

- the older diary source text,
- the retained recent entries,
- the consolidated summary text,
- stage / game / phase / power metadata.

This section lets us compare compression behavior, power/entity retention, and structure by variant family.


```python
review_focus = review_df[
    review_df["variant_id"].isin(
        [
            "V2_baseline_freeform",
            "V3_structured_consolidation",
            "V4_importance_aware",
            "V5_base",
            "V5_unresolved_bias",
        ]
    )
].copy()

review_summary = (
    review_focus.groupby(["run_label", "stage", "variant_id"])[
        [
            "compression_ratio",
            "power_retention_ratio",
            "summary_words",
            "summary_status_tag_count",
            "summary_heading_count",
            "summary_duplicate_line_fraction",
        ]
    ]
    .mean()
    .round(3)
    .reset_index()
)
display(review_summary)

fig, ax = plt.subplots(figsize=(10, 7))
sns.scatterplot(
    data=review_focus,
    x="compression_ratio",
    y="power_retention_ratio",
    hue="variant_id",
    style="stage",
    alpha=0.8,
    ax=ax,
)
ax.set_title("Compression vs retained power/entity signal")
plt.show()
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>compression_ratio</th>
      <th>power_retention_ratio</th>
      <th>summary_words</th>
      <th>summary_status_tag_count</th>
      <th>summary_heading_count</th>
      <th>summary_duplicate_line_fraction</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V2_baseline_freeform</td>
      <td>0.159</td>
      <td>0.971</td>
      <td>208.9</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>0.192</td>
      <td>0.889</td>
      <td>228.7</td>
      <td>0.0</td>
      <td>3.2</td>
      <td>0.004</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V4_importance_aware</td>
      <td>0.227</td>
      <td>0.807</td>
      <td>237.8</td>
      <td>0.0</td>
      <td>4.3</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V2_baseline_freeform</td>
      <td>0.170</td>
      <td>0.544</td>
      <td>290.2</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>0.252</td>
      <td>0.773</td>
      <td>258.5</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>57</th>
      <td>phase1_v5_03</td>
      <td>sanity</td>
      <td>V3_structured_consolidation</td>
      <td>0.333</td>
      <td>0.840</td>
      <td>209.7</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>0.004</td>
    </tr>
    <tr>
      <th>58</th>
      <td>phase1_v5_03</td>
      <td>sanity</td>
      <td>V4_importance_aware</td>
      <td>0.301</td>
      <td>0.851</td>
      <td>207.7</td>
      <td>0.0</td>
      <td>3.6</td>
      <td>0.003</td>
    </tr>
    <tr>
      <th>59</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V2_baseline_freeform</td>
      <td>0.238</td>
      <td>0.986</td>
      <td>240.7</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>60</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>0.245</td>
      <td>0.912</td>
      <td>200.8</td>
      <td>0.0</td>
      <td>2.5</td>
      <td>0.004</td>
    </tr>
    <tr>
      <th>61</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V4_importance_aware</td>
      <td>0.247</td>
      <td>0.816</td>
      <td>197.5</td>
      <td>0.0</td>
      <td>4.2</td>
      <td>0.004</td>
    </tr>
  </tbody>
</table>
<p>62 rows × 9 columns</p>
</div>



    
![png](memory_autoresearch_full_study_files/memory_autoresearch_full_study_16_1.png)
    



```python
representative_packets = mau.choose_representative_review_packets(
    review_focus,
    variants=["V2_baseline_freeform", "V3_structured_consolidation", "V5_base"],
    sort_by="power_retention_ratio",
    ascending=False,
    top_k=1,
).copy()

representative_packets["summary_preview"] = representative_packets["consolidated_summary_text"].str.slice(0, 700)
representative_packets["source_preview"] = representative_packets["source_older_diary_text"].str.slice(0, 400)

display(
    representative_packets[
        [
            "variant_id",
            "stage",
            "phase",
            "power",
            "compression_ratio",
            "power_retention_ratio",
            "summary_status_tag_count",
            "summary_preview",
        ]
    ]
)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variant_id</th>
      <th>stage</th>
      <th>phase</th>
      <th>power</th>
      <th>compression_ratio</th>
      <th>power_retention_ratio</th>
      <th>summary_status_tag_count</th>
      <th>summary_preview</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>V2_baseline_freeform</td>
      <td>sanity</td>
      <td>S1903M</td>
      <td>ITALY</td>
      <td>0.288043</td>
      <td>1.0</td>
      <td>0</td>
      <td>Italy's diplomatic and strategic efforts have focused on securing the Adriatic and Mediterranean regions while managing relations with key powers. Key agree...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>V5_base</td>
      <td>cross_model</td>
      <td>S1906M</td>
      <td>AUSTRIA</td>
      <td>0.120510</td>
      <td>1.0</td>
      <td>9</td>
      <td>### Active Alliances &amp; Agreements\n- France: Strong anti-Italy pincer, coordinating east (AU TYR/BOH/VIE/MUN vs IT TYR/VEN/BOH) and west (FR MAO-WES/POR-SPA...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>V3_structured_consolidation</td>
      <td>sanity</td>
      <td>S1903M</td>
      <td>GERMANY</td>
      <td>0.285015</td>
      <td>1.0</td>
      <td>0</td>
      <td>### Allies and Enemies - **Allies:** Austria and Italy have been reliable allies, supporting Germany's advances into Galicia (GAL) and Bohemia (BOH). Italy ...</td>
    </tr>
  </tbody>
</table>
</div>


## 5. Failure modes from protocol metrics, logs, and prior judge outputs

Failure analysis is intentionally triangulated. We look at:

- protocol failure metrics (`parse_failure_rate`, `contradiction_rate`, `invalid_order_rate`),
- log signatures (`WARNING`, `ERROR`, JSON parse fallback, timeouts, order rejections),
- optional prior qualitative judge outputs if they exist in `memory_metrics_outputs`.


```python
risk_table = aggregates_df[
    [
        "run_label",
        "stage",
        "variant_id",
        "retention_score",
        "contradiction_rate",
        "parse_failure_rate",
        "invalid_order_rate",
        "order_success_rate",
        "mean_final_sc",
    ]
].sort_values(["run_label", "stage", "variant_id"]).reset_index(drop=True)
display(risk_table)

log_summary = (
    log_df.groupby(["run_label", "stage", "variant_id"])[
        [
            "warning_count",
            "error_count",
            "json_fallback_count",
            "resume_count",
            "order_rejected_count",
            "timeout_count",
        ]
    ]
    .mean()
    .round(2)
    .reset_index()
)
display(log_summary)
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>retention_score</th>
      <th>contradiction_rate</th>
      <th>parse_failure_rate</th>
      <th>invalid_order_rate</th>
      <th>order_success_rate</th>
      <th>mean_final_sc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V2_baseline_freeform</td>
      <td>0.876822</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.200182</td>
      <td>0.593607</td>
      <td>4.380952</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>0.969307</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.195517</td>
      <td>0.587385</td>
      <td>4.333333</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V4_importance_aware</td>
      <td>0.959329</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.168956</td>
      <td>0.615509</td>
      <td>4.428571</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V2_baseline_freeform</td>
      <td>0.908294</td>
      <td>0.021470</td>
      <td>0.0</td>
      <td>0.022144</td>
      <td>0.686991</td>
      <td>4.857143</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>0.938164</td>
      <td>0.032994</td>
      <td>0.0</td>
      <td>0.013427</td>
      <td>0.650870</td>
      <td>4.857143</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83</th>
      <td>phase1_v5_03</td>
      <td>sanity</td>
      <td>V5_mutation_03</td>
      <td>0.967687</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.147959</td>
      <td>0.571429</td>
      <td>4.428571</td>
    </tr>
    <tr>
      <th>84</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V2_baseline_freeform</td>
      <td>0.937139</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.206397</td>
      <td>0.614693</td>
      <td>4.071429</td>
    </tr>
    <tr>
      <th>85</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>0.975957</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.194508</td>
      <td>0.590372</td>
      <td>4.071429</td>
    </tr>
    <tr>
      <th>86</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V4_importance_aware</td>
      <td>0.964464</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.147859</td>
      <td>0.646196</td>
      <td>4.071429</td>
    </tr>
    <tr>
      <th>87</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V5_mutation_03</td>
      <td>0.975957</td>
      <td>0.003720</td>
      <td>0.0</td>
      <td>0.185579</td>
      <td>0.626286</td>
      <td>4.071429</td>
    </tr>
  </tbody>
</table>
<p>88 rows × 9 columns</p>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>run_label</th>
      <th>stage</th>
      <th>variant_id</th>
      <th>warning_count</th>
      <th>error_count</th>
      <th>json_fallback_count</th>
      <th>resume_count</th>
      <th>order_rejected_count</th>
      <th>timeout_count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V2_baseline_freeform</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>112.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V3_structured_consolidation</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>112.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>mem-v2</td>
      <td>confirmation</td>
      <td>V4_importance_aware</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>112.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V2_baseline_freeform</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.5</td>
      <td>0.0</td>
      <td>1.5</td>
    </tr>
    <tr>
      <th>4</th>
      <td>mem-v2</td>
      <td>cross_model</td>
      <td>V3_structured_consolidation</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7.5</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>87</th>
      <td>phase1_v5_03</td>
      <td>sanity</td>
      <td>V5_mutation_03</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>42.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>88</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V2_baseline_freeform</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>70.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>89</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V3_structured_consolidation</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>70.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>90</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V4_importance_aware</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>70.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>91</th>
      <td>phase1_v5_03</td>
      <td>screening</td>
      <td>V5_mutation_03</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>70.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>4.5</td>
    </tr>
  </tbody>
</table>
<p>92 rows × 9 columns</p>
</div>



```python
if not combined_variant_metrics_df.empty:
    behavior_proxy_cols = [
        "variant_id",
        "runs",
        "avg_bounce_rate",
        "avg_hard_failed_rate",
        "avg_disrupted_rate",
        "avg_commitment_adherence_proxy",
        "avg_support_accuracy_proxy",
        "avg_memory_to_order_alignment_proxy",
        "betrayal_stickiness_2phase",
        "enemy_targeting_consistency",
    ]
    display(Markdown("### Optional behavior proxies from prior analysis exports"))
    display(combined_variant_metrics_df[behavior_proxy_cols].sort_values("variant_id").reset_index(drop=True))
else:
    print("No `combined_variant_metrics.csv` export found; skipping behavior proxies.")
```


### Optional behavior proxies from prior analysis exports



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variant_id</th>
      <th>runs</th>
      <th>avg_bounce_rate</th>
      <th>avg_hard_failed_rate</th>
      <th>avg_disrupted_rate</th>
      <th>avg_commitment_adherence_proxy</th>
      <th>avg_support_accuracy_proxy</th>
      <th>avg_memory_to_order_alignment_proxy</th>
      <th>betrayal_stickiness_2phase</th>
      <th>enemy_targeting_consistency</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>V0_no_memory</td>
      <td>2</td>
      <td>0.187486</td>
      <td>0.203887</td>
      <td>0.237707</td>
      <td>0.155291</td>
      <td>0.165618</td>
      <td>0.990055</td>
      <td>0.196388</td>
      <td>0.094808</td>
    </tr>
    <tr>
      <th>1</th>
      <td>V2_baseline_freeform</td>
      <td>2</td>
      <td>0.194697</td>
      <td>0.206902</td>
      <td>0.240850</td>
      <td>0.110131</td>
      <td>0.100379</td>
      <td>0.998696</td>
      <td>0.263591</td>
      <td>0.141680</td>
    </tr>
    <tr>
      <th>2</th>
      <td>V3_structured_consolidation</td>
      <td>4</td>
      <td>0.221724</td>
      <td>0.233452</td>
      <td>0.278532</td>
      <td>0.138654</td>
      <td>0.155388</td>
      <td>0.994613</td>
      <td>0.194326</td>
      <td>0.101655</td>
    </tr>
    <tr>
      <th>3</th>
      <td>V5_base</td>
      <td>2</td>
      <td>0.233909</td>
      <td>0.247027</td>
      <td>0.276892</td>
      <td>0.097637</td>
      <td>0.066092</td>
      <td>0.999359</td>
      <td>0.256873</td>
      <td>0.128007</td>
    </tr>
  </tbody>
</table>
</div>



```python
if not judge_error_df.empty:
    display(Markdown("### Prior LLM judge outputs (loaded from `memory_metrics_outputs`)"))
    effect_by_variant = judge_error_df.groupby(["variant_id", "memory_effect_label"]).size().unstack(fill_value=0)
    collapse_by_variant = judge_error_df.groupby(["variant_id", "collapse_type"]).size().unstack(fill_value=0)
    main_failures = (
        judge_error_df.groupby(["variant_id", "main_failure"])
        .size()
        .reset_index(name="count")
        .sort_values(["variant_id", "count"], ascending=[True, False])
    )
    display(effect_by_variant)
    display(collapse_by_variant)
    display(main_failures.groupby("variant_id", group_keys=False).head(5))
else:
    print("No prior LLM judge CSV found; skipping this subsection.")
```


### Prior LLM judge outputs (loaded from `memory_metrics_outputs`)



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>memory_effect_label</th>
      <th>harmful</th>
      <th>missing</th>
      <th>mixed</th>
      <th>overloaded</th>
      <th>useful</th>
    </tr>
    <tr>
      <th>variant_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>V0_no_memory</th>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>V2_baseline_freeform</th>
      <td>0</td>
      <td>0</td>
      <td>11</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>V3_structured_consolidation</th>
      <td>0</td>
      <td>1</td>
      <td>12</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>V5_base</th>
      <td>2</td>
      <td>0</td>
      <td>9</td>
      <td>1</td>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>collapse_type</th>
      <th>coordination_failure</th>
      <th>missing_memory</th>
      <th>none</th>
      <th>order_intent_mismatch</th>
      <th>overloaded_memory</th>
      <th>overtrust</th>
      <th>timeline_contamination</th>
    </tr>
    <tr>
      <th>variant_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>V0_no_memory</th>
      <td>1</td>
      <td>0</td>
      <td>5</td>
      <td>5</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>V2_baseline_freeform</th>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>5</td>
      <td>5</td>
      <td>0</td>
      <td>2</td>
    </tr>
    <tr>
      <th>V3_structured_consolidation</th>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>6</td>
      <td>3</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>V5_base</th>
      <td>0</td>
      <td>0</td>
      <td>4</td>
      <td>3</td>
      <td>6</td>
      <td>0</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variant_id</th>
      <th>main_failure</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>V0_no_memory</td>
      <td>Broke the planned/communicated support for Germany’s GAL push by ordering holds with WAR/UKR</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>V0_no_memory</td>
      <td>Orders contradict stated ENG-coordinated anti-FRA plan (BEL should move to RUH; HOL should hold), with apparent timeline-contaminated diary entries</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>V0_no_memory</td>
      <td>Orders deviate from stated spring intent (MAR-&gt;SPA instead of MAR-&gt;BUR) and memory contains same-phase post-results (timeline contamination).</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>V0_no_memory</td>
      <td>Orders mostly follow the stated anti-France/Germany-coordination plan, but NWY move conflicts with the explicitly logged intent and memory contains same-pha...</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>V0_no_memory</td>
      <td>Orders only partially match stated S1903M intent and memory contains same-phase post-adjudication results</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15</th>
      <td>V2_baseline_freeform</td>
      <td>Diary contains post-adjudication reflections mixed into same-phase intent (timeline contamination), though orders match stated plan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>16</th>
      <td>V2_baseline_freeform</td>
      <td>Diary contains timeline-contaminated post-adjudication reflection duplicated within the same phase</td>
      <td>1</td>
    </tr>
    <tr>
      <th>17</th>
      <td>V2_baseline_freeform</td>
      <td>Diary log mixes pre-move intent with post-adjudication reflection from the same phase</td>
      <td>1</td>
    </tr>
    <tr>
      <th>18</th>
      <td>V2_baseline_freeform</td>
      <td>Planned Balkan captures (GRE-&gt;BUL/SC, ALB-&gt;SER) were replaced by GRE hold + ALB support, despite stated solo-aggro east intent; diary also appears to mix pr...</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19</th>
      <td>V2_baseline_freeform</td>
      <td>Planned Norway convoy per goals/allies but submitted full holds again; diary also shows timeline contamination with post-order analysis</td>
      <td>1</td>
    </tr>
    <tr>
      <th>30</th>
      <td>V3_structured_consolidation</td>
      <td>Agent memory/diary/trust context is missing, so memory-conditioned intent cannot be verified beyond message-stated plan</td>
      <td>1</td>
    </tr>
    <tr>
      <th>31</th>
      <td>V3_structured_consolidation</td>
      <td>One submitted move (F LVP-CLY) does not match the phase-stated intent (F LVP-EDI), and the diary mixes intent with post-hoc justification</td>
      <td>1</td>
    </tr>
    <tr>
      <th>32</th>
      <td>V3_structured_consolidation</td>
      <td>Orders contradict stated fall intent/commitments (HOL/BAL plan, Russia NAP), with apparent timeline contamination in memory</td>
      <td>1</td>
    </tr>
    <tr>
      <th>33</th>
      <td>V3_structured_consolidation</td>
      <td>Orders contradict stated pre-move intent/agreements; phase notes also appear timeline-contaminated with post-adjudication reflection</td>
      <td>1</td>
    </tr>
    <tr>
      <th>34</th>
      <td>V3_structured_consolidation</td>
      <td>Orders directly contradict stated plan to attack France and instead (attempt to) support French SKA into NTH while not executing planned NTH-&gt;BEL or WAL-&gt;LVP.</td>
      <td>1</td>
    </tr>
    <tr>
      <th>45</th>
      <td>V5_base</td>
      <td>Diary contains timeline-contaminated post-adjudication claims within the same phase</td>
      <td>1</td>
    </tr>
    <tr>
      <th>46</th>
      <td>V5_base</td>
      <td>Did not execute planned VIE support for BOH-&gt;MUN, instead moved VIE-&gt;TRI</td>
      <td>1</td>
    </tr>
    <tr>
      <th>47</th>
      <td>V5_base</td>
      <td>Did not follow stated intent to move A ROM to PIE (held instead), weakening declared France-trust/west posture</td>
      <td>1</td>
    </tr>
    <tr>
      <th>48</th>
      <td>V5_base</td>
      <td>Minor timeline contamination in memory log (intent and results both recorded for same phase)</td>
      <td>1</td>
    </tr>
    <tr>
      <th>49</th>
      <td>V5_base</td>
      <td>Orders contradict stated F1901M intent (CHA + support) and reflect timeline-contaminated post-results notes</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>


## 6. Optional OpenRouter qualitative analysis

This final section is optional. If `OPENROUTER_API_KEY` is present, the notebook can run:

- **pointwise qualitative rating** of memory packets, and
- **mirrored pairwise comparisons** to reduce position bias when comparing variants.

Suggested default workflow:

1. rate a handful of representative packets pointwise,
2. compare `V3` vs `V2`,
3. compare accepted `V5_base` vs `V3`,
4. inspect disagreements between forward and reversed order.


```python
LLM_MODEL = os.getenv("OPENROUTER_NOTEBOOK_MODEL", "openai/gpt-5.2")
OPENROUTER_READY = mau.openrouter_available()
RUN_OPENROUTER_ANALYSIS = os.getenv("RUN_OPENROUTER_ANALYSIS", "").strip().lower() in {"1", "true", "yes"}

llm_packet_candidates = representative_packets.copy()
display(llm_packet_candidates[["variant_id", "stage", "phase", "power", "compression_ratio", "power_retention_ratio"]])

print(f"OpenRouter ready: {OPENROUTER_READY}")
print(f"Run OpenRouter analysis now: {RUN_OPENROUTER_ANALYSIS}")
print(f"Judge model: {LLM_MODEL}")
print(f"Cache dir: {CACHE_DIR}")
```


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>variant_id</th>
      <th>stage</th>
      <th>phase</th>
      <th>power</th>
      <th>compression_ratio</th>
      <th>power_retention_ratio</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>V2_baseline_freeform</td>
      <td>sanity</td>
      <td>S1903M</td>
      <td>ITALY</td>
      <td>0.288043</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>V5_base</td>
      <td>cross_model</td>
      <td>S1906M</td>
      <td>AUSTRIA</td>
      <td>0.120510</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>V3_structured_consolidation</td>
      <td>sanity</td>
      <td>S1903M</td>
      <td>GERMANY</td>
      <td>0.285015</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>


    OpenRouter ready: False
    Run OpenRouter analysis now: False
    Judge model: openai/gpt-5.2
    Cache dir: /Users/anatolelobenko/Downloads/AI_Diplomacy-main/analysis/notebook_cache/openrouter



```python
if RUN_OPENROUTER_ANALYSIS and OPENROUTER_READY and not llm_packet_candidates.empty:
    pointwise_rows = []
    for _, row in llm_packet_candidates.iterrows():
        packet = mau.review_packet_for_llm(row)
        result = mau.llm_rate_review_packet(
            packet,
            model=LLM_MODEL,
            cache_dir=CACHE_DIR / "pointwise",
        )
        pointwise_rows.append(
            {
                "variant_id": row["variant_id"],
                "stage": row["stage"],
                "phase": row["phase"],
                "power": row["power"],
                **result,
            }
        )
    pointwise_df = pd.DataFrame(pointwise_rows)
    display(pointwise_df)
else:
    print("Skipping live qualitative analysis. Set RUN_OPENROUTER_ANALYSIS=1 (and OPENROUTER_API_KEY) to enable it.")
```


```python
if RUN_OPENROUTER_ANALYSIS and OPENROUTER_READY:
    pair_rows = []
    pair_specs = [
        ("V3_structured_consolidation", "V2_baseline_freeform"),
        ("V5_base", "V3_structured_consolidation"),
    ]

    for left_variant, right_variant in pair_specs:
        left_rows = llm_packet_candidates[llm_packet_candidates["variant_id"] == left_variant]
        right_rows = llm_packet_candidates[llm_packet_candidates["variant_id"] == right_variant]
        if left_rows.empty or right_rows.empty:
            continue

        left_packet = mau.review_packet_for_llm(left_rows.iloc[0])
        right_packet = mau.review_packet_for_llm(right_rows.iloc[0])
        verdict = mau.llm_compare_review_packets(
            left_packet,
            right_packet,
            model=LLM_MODEL,
            cache_dir=CACHE_DIR / "pairwise",
            mirrored=True,
        )
        pair_rows.append(
            {
                "left_variant": left_variant,
                "right_variant": right_variant,
                "winner_consensus": verdict.get("winner_consensus"),
                "faithfulness_consensus": verdict.get("faithfulness_winner_consensus"),
                "salience_consensus": verdict.get("salience_winner_consensus"),
                "actionability_consensus": verdict.get("actionability_winner_consensus"),
                "freshness_consensus": verdict.get("freshness_winner_consensus"),
                "robustness_consensus": verdict.get("robustness_winner_consensus"),
                "raw_verdict": json.dumps(verdict, ensure_ascii=False)[:1200],
            }
        )

    if pair_rows:
        display(pd.DataFrame(pair_rows))
    else:
        print("No pairwise packet pairs were available in the sampled representatives.")
else:
    print("Skipping live pairwise comparison. Set RUN_OPENROUTER_ANALYSIS=1 (and OPENROUTER_API_KEY) to enable it.")
```

## 7. Practical extensions

Natural next steps for this notebook:

- add a dedicated **hard-pruning** ablation layer,
- score **phase-local** memory artifacts rather than only final consolidated diaries,
- compare **same-power same-phase** packets across variants where a tighter pairing is available,
- export notebook tables to a paper-ready appendix.
