from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import httpx
import numpy as np
import pandas as pd
from scipy.stats import bootstrap, permutation_test, spearmanr


POWERS = [
    "AUSTRIA",
    "ENGLAND",
    "FRANCE",
    "GERMANY",
    "ITALY",
    "RUSSIA",
    "TURKEY",
]

POWER_ALIASES: dict[str, tuple[str, ...]] = {
    "AUSTRIA": ("AUSTRIA", "AUS", "A"),
    "ENGLAND": ("ENGLAND", "ENG", "E"),
    "FRANCE": ("FRANCE", "FRA", "F"),
    "GERMANY": ("GERMANY", "GER", "G"),
    "ITALY": ("ITALY", "ITA", "I"),
    "RUSSIA": ("RUSSIA", "RUS", "R"),
    "TURKEY": ("TURKEY", "TUR", "T"),
}
POWER_ALIAS_PATTERNS: dict[str, re.Pattern[str]] = {
    power: re.compile(
        r"(?<![A-Z])(?:"
        + "|".join(re.escape(alias) for alias in aliases)
        + r")(?![A-Z])"
    )
    for power, aliases in POWER_ALIASES.items()
}
STATUS_TAG_PATTERN = re.compile(r"\[(confirmed|tentative|broken|stale)\]", flags=re.I)
HEADING_PATTERN = re.compile(r"^#{2,3}\s+(.+)$", flags=re.M)
BULLET_PATTERN = re.compile(r"^\s*[-*]\s+", flags=re.M)
V3_SECTION_MARKERS = {
    "Allies and Enemies",
    "Trust and Betrayals",
    "Open Commitments",
    "Active Goals",
    "Persistent Threats and Opportunities",
    "Strategic Lessons",
}
V5_SECTION_MARKERS = {
    "Active Alliances & Agreements",
    "Broken Alliances & Betrayals",
    "Active Diplomatic Commitments",
    "Military Objectives & Unit Positions",
    "Threats & Watchlist",
    "Historical Lessons & Event Outcomes",
}
LOG_PATTERNS = {
    "http_ok_count": r"HTTP/1\.1 200 OK",
    "warning_count": r"\bWARNING:",
    "error_count": r"\bERROR:",
    "json_fallback_count": r"Failed to parse formatted response as JSON",
    "resume_count": r"Successfully resumed game from phase",
    "empty_diary_preview_count": r"Preview: \(No diary entries yet\)",
    "recent_diary_preview_count": r"Preview: --- RECENT FULL DIARY ENTRIES ---",
    "consolidated_preview_count": r"Preview: \[CONSOLIDATED HISTORY\]",
    "order_rejected_count": r"Rejected by engine",
    "timeout_count": r"(ReadTimeout|timed out|TimeoutError)",
}
QUALITATIVE_METHOD_SOURCES = [
    {
        "topic": "Bootstrap confidence intervals",
        "source": "SciPy bootstrap docs",
        "url": "https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.bootstrap.html",
        "note": "BCa intervals are a good default for small and skewed samples.",
    },
    {
        "topic": "Permutation tests",
        "source": "SciPy permutation_test docs",
        "url": "https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.permutation_test.html",
        "note": "Useful when sample sizes are small and parametric assumptions are weak.",
    },
    {
        "topic": "Spearman rank correlation",
        "source": "SciPy spearmanr docs",
        "url": "https://docs.scipy.org/doc/scipy-1.15.1/reference/generated/scipy.stats.spearmanr.html",
        "note": "Nonparametric monotonic association; SciPy warns p-values are only accurate for large samples.",
    },
    {
        "topic": "LLM form-filling evaluation",
        "source": "G-Eval (OpenReview)",
        "url": "https://openreview.net/forum?id=puMfaHb1hY",
        "note": "Motivates structured rubrics and form-filling for LLM-based qualitative evaluation.",
    },
    {
        "topic": "Bias checks for LLM-as-judge",
        "source": "Pairwise meta-evaluator paper",
        "url": "https://www.mdpi.com/2078-2489/16/8/652",
        "note": "Supports mirrored pairwise comparisons to diagnose order and evaluator instability.",
    },
    {
        "topic": "OpenRouter API support",
        "source": "OpenRouter chat completion docs",
        "url": "https://openrouter.ai/docs/api-reference/chat-completion",
        "note": "Documents the chat-completions endpoint used for optional notebook-side qualitative analysis.",
    },
]


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def safe_read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def ensure_path(value: str | Path) -> Path:
    return value if isinstance(value, Path) else Path(value)


def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or ""))


def duplicate_line_fraction(text: str) -> float:
    lines = [line.strip() for line in (text or "").splitlines() if line.strip()]
    if not lines:
        return 0.0
    unique = len(set(lines))
    return max(0.0, 1.0 - unique / len(lines))


def power_mentions(text: str) -> list[str]:
    upper_text = (text or "").upper()
    return [power for power, pattern in POWER_ALIAS_PATTERNS.items() if pattern.search(upper_text)]


def extract_status_tags(text: str) -> list[str]:
    return STATUS_TAG_PATTERN.findall(text or "")


def extract_headings(text: str) -> list[str]:
    return [match.strip() for match in HEADING_PATTERN.findall(text or "")]


def text_feature_dict(text: str) -> dict[str, Any]:
    text = text or ""
    powers = power_mentions(text.upper())
    headings = extract_headings(text)
    status_tags = extract_status_tags(text)
    return {
        "text_chars": len(text),
        "text_words": word_count(text),
        "line_count": len([line for line in text.splitlines() if line.strip()]),
        "bullet_count": len(BULLET_PATTERN.findall(text)),
        "heading_count": len(headings),
        "heading_names": headings,
        "distinct_power_mentions": len(set(powers)),
        "power_mention_count": len(powers),
        "status_tag_count": len(status_tags),
        "status_tag_types": sorted(set(tag.lower() for tag in status_tags)),
        "duplicate_line_fraction": duplicate_line_fraction(text),
        "contains_v3_heading_set": int(V3_SECTION_MARKERS.issubset(set(headings))),
        "contains_v5_heading_set": int(V5_SECTION_MARKERS.issubset(set(headings))),
    }


def default_run_registry(root: str | Path) -> pd.DataFrame:
    root = ensure_path(root)
    results_root = root / "results" / "autoresearch"
    records: list[dict[str, Any]] = []

    explicit = [
        {
            "run_label": "mem-v2",
            "run_root": results_root / "mem-v2",
            "cohort": "baseline-benchmark",
            "authority": "authoritative",
            "include_by_default": True,
            "notes": "Main V0-V4 benchmark with V3 as final pre-V5 incumbent.",
        },
        {
            "run_label": "mem-v5-final",
            "run_root": results_root / "mem-v5-20260424__phase2_phase1_v5_03",
            "cohort": "v5-family",
            "authority": "authoritative",
            "include_by_default": True,
            "notes": "Authoritative final V5 family run; V5_base defeats V3 in cross-model.",
        },
        {
            "run_label": "mem-v5-v0-cross-model",
            "run_root": results_root / "mem-v5-20260424__v0_cross_model_grok",
            "cohort": "control",
            "authority": "authoritative",
            "include_by_default": True,
            "notes": "Standalone V0 no-memory Grok cross-model control.",
        },
        {
            "run_label": "mem-v5-phase2-exploratory",
            "run_root": results_root / "mem-v5-20260424__phase2",
            "cohort": "v5-family",
            "authority": "exploratory",
            "include_by_default": False,
            "notes": "Exploratory branch retained for archival comparison only.",
        },
    ]

    phase1_roots = sorted(results_root.glob("mem-v5-20260424__phase1_v5_*"))
    for phase1_root in phase1_roots:
        records.append(
            {
                "run_label": phase1_root.name.replace("mem-v5-20260424__", ""),
                "run_root": phase1_root,
                "cohort": "v5-phase1-search",
                "authority": "authoritative",
                "include_by_default": True,
                "notes": "Phase-1 V5 mutation-search candidate run.",
            }
        )

    records.extend(explicit)
    rows = [
        row
        for row in records
        if ensure_path(row["run_root"]).exists()
    ]
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    return df.sort_values(["cohort", "run_label"]).reset_index(drop=True)


def variant_metadata_frame() -> pd.DataFrame:
    rows = [
        {
            "variant_id": "V0_no_memory",
            "family": "control",
            "memory_mode": "no prompt-visible memory",
            "description": "Private diary exists for logging but is not re-injected into later prompts.",
        },
        {
            "variant_id": "V1_raw_verbatim_window",
            "family": "control",
            "memory_mode": "raw recency window",
            "description": "Retains recent diary text verbatim without consolidation.",
        },
        {
            "variant_id": "V2_baseline_freeform",
            "family": "baseline",
            "memory_mode": "year plus freeform summary",
            "description": "Baseline freeform summary of older history with one recent year kept verbatim.",
        },
        {
            "variant_id": "V3_structured_consolidation",
            "family": "structured",
            "memory_mode": "fixed semantic headings",
            "description": "Same budget as V2 but uses fixed structured headings for consolidation.",
        },
        {
            "variant_id": "V4_importance_aware",
            "family": "structured",
            "memory_mode": "importance-aware retention",
            "description": "Structured consolidation plus salience-aware carry-forward of unresolved facts.",
        },
        {
            "variant_id": "V5_change_aware_structured",
            "family": "v5-search",
            "memory_mode": "change-aware schema",
            "description": "Initial V5 candidate with explicit stable-vs-reversal sections.",
        },
        {
            "variant_id": "V5_mutation_01",
            "family": "v5-search",
            "memory_mode": "change-aware schema mutation 1",
            "description": "Merged redundant sections and increased betrayal emphasis.",
        },
        {
            "variant_id": "V5_mutation_02",
            "family": "v5-search",
            "memory_mode": "change-aware schema mutation 2",
            "description": "Exact headings plus event citations and stronger unit specificity.",
        },
        {
            "variant_id": "V5_mutation_03",
            "family": "v5-search",
            "memory_mode": "change-aware schema mutation 3",
            "description": "Clarified active vs broken commitments and tightened schema rules.",
        },
        {
            "variant_id": "V5_base",
            "family": "v5-family",
            "memory_mode": "accepted V5 schema",
            "description": "Final accepted V5 structure with the base V3-equivalent budget split.",
        },
        {
            "variant_id": "V5_recent2",
            "family": "v5-family",
            "memory_mode": "accepted V5 schema, recency-heavy",
            "description": "Two recent years kept verbatim with a smaller older-history block.",
        },
        {
            "variant_id": "V5_history_heavy",
            "family": "v5-family",
            "memory_mode": "accepted V5 schema, history-heavy",
            "description": "Larger budget allocated to consolidated older history.",
        },
        {
            "variant_id": "V5_unresolved_bias",
            "family": "v5-family",
            "memory_mode": "accepted V5 schema, unresolved-first",
            "description": "Prioritizes unresolved commitments and betrayals over completed plans.",
        },
    ]
    return pd.DataFrame(rows)


def load_stage_summary_tables(run_root: str | Path, run_label: str | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    run_root = ensure_path(run_root)
    run_label = run_label or run_root.name
    stage_summary_path = run_root / "stage_summary.json"
    if not stage_summary_path.exists():
        return pd.DataFrame(), pd.DataFrame()

    stage_summary = load_json(stage_summary_path)
    aggregate_rows: list[dict[str, Any]] = []
    leaderboard_rows: list[dict[str, Any]] = []

    for stage_name, payload in stage_summary.items():
        for row in payload.get("aggregates", []):
            aggregate_rows.append({"run_label": run_label, "run_root": str(run_root), **row})
        for row in payload.get("leaderboard", []):
            leaderboard_rows.append({"run_label": run_label, "run_root": str(run_root), **row})

    return pd.DataFrame(aggregate_rows), pd.DataFrame(leaderboard_rows)


def load_run_registry_stage_tables(run_registry: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    aggregate_frames = []
    leaderboard_frames = []
    for row in run_registry.to_dict(orient="records"):
        aggs, leaders = load_stage_summary_tables(row["run_root"], row["run_label"])
        if not aggs.empty:
            aggregate_frames.append(aggs)
        if not leaders.empty:
            leaderboard_frames.append(leaders)
    aggregate_df = pd.concat(aggregate_frames, ignore_index=True) if aggregate_frames else pd.DataFrame()
    leaderboard_df = pd.concat(leaderboard_frames, ignore_index=True) if leaderboard_frames else pd.DataFrame()
    return aggregate_df, leaderboard_df


def _parse_stage_variant_game_from_path(path: Path, run_root: Path) -> tuple[str | None, str | None, str | None]:
    rel_parts = path.relative_to(run_root).parts
    if len(rel_parts) < 4:
        return None, None, None
    return rel_parts[0], rel_parts[1], rel_parts[2]

def _supply_center_count(value: Any) -> float:
    if isinstance(value, (int, float, np.integer, np.floating)):
        return float(value)

    if isinstance(value, Mapping):
        for key in ("count", "n", "num_supply_centers", "final_supply_center_count"):
            candidate = value.get(key)
            if isinstance(candidate, (int, float, np.integer, np.floating)):
                return float(candidate)

        for key in ("supply_centers", "centers", "owned_centers"):
            candidate = value.get(key)
            if isinstance(candidate, (list, tuple, set, Mapping)):
                return float(len(candidate))

        return float(len(value))

    if isinstance(value, (list, tuple, set)):
        return float(len(value))

    return np.nan

def load_experiment_game_rows(run_root: str | Path, run_label: str | None = None) -> pd.DataFrame:
    run_root = ensure_path(run_root)
    run_label = run_label or run_root.name
    rows: list[dict[str, Any]] = []

    for summary_path in sorted(run_root.glob("*/*/experiment_summary.json")):
        rel_parts = summary_path.relative_to(run_root).parts
        if len(rel_parts) < 3:
            continue
        stage_name, variant_id = rel_parts[0], rel_parts[1]
        payload = load_json(summary_path)
        for game_key, result in (payload.get("results") or {}).items():
            sc_map = result.get("supply_centers") or {}
            winner = result.get("winner")
            rows.append(
                {
                    "run_label": run_label,
                    "run_root": str(run_root),
                    "stage": stage_name,
                    "variant_id": variant_id,
                    "game_key": game_key,
                    "game_dir": result.get("run_dir"),
                    "elapsed_seconds": result.get("elapsed_seconds"),
                    "final_phase": result.get("final_phase"),
                    "winner": winner,
                    "winner_sc": (
                        _supply_center_count(sc_map.get(winner))
                        if isinstance(sc_map, Mapping) and winner is not None
                        else np.nan
                    ),
                    "supply_centers_total": (
                        sum(
                            count
                            for count in (_supply_center_count(v) for v in sc_map.values())
                            if pd.notna(count)
                        )
                        if isinstance(sc_map, Mapping)
                        else np.nan
                    ),
                    "supply_centers": sc_map,
                    "agent_memories_dir": result.get("agent_memories_dir"),
                }
            )
    return pd.DataFrame(rows)


def load_run_registry_game_rows(run_registry: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for row in run_registry.to_dict(orient="records"):
        frame = load_experiment_game_rows(row["run_root"], row["run_label"])
        if not frame.empty:
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def load_agent_memory_rows(run_root: str | Path, run_label: str | None = None) -> pd.DataFrame:
    run_root = ensure_path(run_root)
    run_label = run_label or run_root.name
    rows: list[dict[str, Any]] = []

    for memory_path in sorted(run_root.glob("*/*/game_*/agent_memories/*_memory.json")):
        stage_name, variant_id, game_key = _parse_stage_variant_game_from_path(memory_path, run_root)
        payload = load_json(memory_path)
        diary = payload.get("consolidated_diary") or ""
        goals = payload.get("final_goals") or []
        trust_scores = payload.get("final_trust_scores") or {}
        relationships = payload.get("final_relationships") or {}
        outcome = payload.get("game_outcome") or {}
        features = text_feature_dict(diary)
        rows.append(
            {
                "run_label": run_label,
                "run_root": str(run_root),
                "stage": stage_name,
                "variant_id": variant_id,
                "game_key": game_key,
                "power_name": payload.get("power_name") or memory_path.stem.replace("_memory", ""),
                "consolidated_diary": diary,
                "goal_count": len(goals),
                "final_goals": goals,
                "final_relationships": relationships,
                "final_trust_scores": trust_scores,
                "mean_trust": float(np.mean(list(trust_scores.values()))) if trust_scores else np.nan,
                "std_trust": float(np.std(list(trust_scores.values()))) if trust_scores else np.nan,
                "n_positive_relationships": sum(1 for value in relationships.values() if str(value).lower() == "friendly"),
                "n_negative_relationships": sum(1 for value in relationships.values() if str(value).lower() == "unfriendly"),
                "final_supply_center_count": outcome.get("final_supply_center_count"),
                "survived": outcome.get("survived"),
                "won": outcome.get("won"),
                "draw": outcome.get("draw"),
                "final_year": outcome.get("final_year"),
                **features,
            }
        )
    return pd.DataFrame(rows)


def load_run_registry_agent_memories(run_registry: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for row in run_registry.to_dict(orient="records"):
        frame = load_agent_memory_rows(row["run_root"], row["run_label"])
        if not frame.empty:
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def _shared_power_retention(source_text: str, summary_text: str) -> tuple[int, int, float]:
    source_powers = set(power_mentions((source_text or "").upper()))
    summary_powers = set(power_mentions((summary_text or "").upper()))
    if not source_powers:
        return 0, len(summary_powers), np.nan
    shared = len(source_powers & summary_powers)
    return shared, len(summary_powers), shared / len(source_powers)


def load_manual_review_rows(run_root: str | Path, run_label: str | None = None) -> pd.DataFrame:
    run_root = ensure_path(run_root)
    run_label = run_label or run_root.name
    review_path = run_root / "manual_review_queue.json"
    if not review_path.exists():
        return pd.DataFrame()

    payload = load_json(review_path)
    rows: list[dict[str, Any]] = []
    for idx, row in enumerate(payload):
        source = row.get("source_older_diary_text") or ""
        summary = row.get("consolidated_summary_text") or ""
        recent_entries = row.get("recent_retained_entries") or []
        shared_powers, summary_power_count, power_retention_ratio = _shared_power_retention(source, summary)
        source_features = text_feature_dict(source)
        summary_features = text_feature_dict(summary)
        rows.append(
            {
                "run_label": run_label,
                "run_root": str(run_root),
                "packet_idx": idx,
                **row,
                "source_words": word_count(source),
                "summary_words": word_count(summary),
                "recent_words": sum(word_count(str(item)) for item in recent_entries),
                "retained_entry_count": len(recent_entries),
                "compression_ratio": (word_count(summary) / word_count(source)) if word_count(source) else np.nan,
                "shared_power_mentions": shared_powers,
                "summary_distinct_power_mentions": summary_power_count,
                "power_retention_ratio": power_retention_ratio,
                "source_heading_count": source_features["heading_count"],
                "summary_heading_count": summary_features["heading_count"],
                "summary_status_tag_count": summary_features["status_tag_count"],
                "summary_duplicate_line_fraction": summary_features["duplicate_line_fraction"],
                "summary_contains_v3_heading_set": summary_features["contains_v3_heading_set"],
                "summary_contains_v5_heading_set": summary_features["contains_v5_heading_set"],
            }
        )
    return pd.DataFrame(rows)


def load_run_registry_manual_reviews(run_registry: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for row in run_registry.to_dict(orient="records"):
        frame = load_manual_review_rows(row["run_root"], row["run_label"])
        if not frame.empty:
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def _sample_matching_lines(text: str, prefix_pattern: str, max_lines: int = 3) -> list[str]:
    lines = []
    for line in (text or "").splitlines():
        if re.search(prefix_pattern, line):
            lines.append(line.strip())
        if len(lines) >= max_lines:
            break
    return lines


def load_log_rows(run_root: str | Path, run_label: str | None = None) -> pd.DataFrame:
    run_root = ensure_path(run_root)
    run_label = run_label or run_root.name
    rows: list[dict[str, Any]] = []

    for log_path in sorted(run_root.glob("*/*/game_*/general_game.log")):
        stage_name, variant_id, game_key = _parse_stage_variant_game_from_path(log_path, run_root)
        text = safe_read_text(log_path)
        counts = {
            column: len(re.findall(pattern, text))
            for column, pattern in LOG_PATTERNS.items()
        }
        ended_match = re.search(r"Game ended after ([0-9.]+)s", text)
        rows.append(
            {
                "run_label": run_label,
                "run_root": str(run_root),
                "stage": stage_name,
                "variant_id": variant_id,
                "game_key": game_key,
                "log_path": str(log_path),
                "log_chars": len(text),
                "game_ended_seconds": float(ended_match.group(1)) if ended_match else np.nan,
                "warning_examples": _sample_matching_lines(text, r"\bWARNING:"),
                "error_examples": _sample_matching_lines(text, r"\bERROR:"),
                **counts,
            }
        )
    return pd.DataFrame(rows)


def load_run_registry_logs(run_registry: pd.DataFrame) -> pd.DataFrame:
    frames = []
    for row in run_registry.to_dict(orient="records"):
        frame = load_log_rows(row["run_root"], row["run_label"])
        if not frame.empty:
            frames.append(frame)
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def load_optional_memory_metric_exports(root: str | Path) -> dict[str, pd.DataFrame]:
    root = ensure_path(root)
    metric_root = root / "results" / "autoresearch" / "memory_metrics_outputs"
    if not metric_root.exists():
        return {}
    output: dict[str, pd.DataFrame] = {}
    for csv_path in sorted(metric_root.glob("*.csv")):
        output[csv_path.stem] = pd.read_csv(csv_path)
    return output


def bootstrap_mean_ci(values: Sequence[float], confidence_level: float = 0.95, n_resamples: int = 9999, seed: int = 0) -> dict[str, float]:
    arr = np.asarray([value for value in values if pd.notna(value)], dtype=float)
    if arr.size == 0:
        return {"n": 0, "mean": np.nan, "ci_low": np.nan, "ci_high": np.nan}
    if arr.size == 1:
        return {"n": 1, "mean": float(arr[0]), "ci_low": float(arr[0]), "ci_high": float(arr[0])}

    result = bootstrap(
        (arr,),
        np.mean,
        confidence_level=confidence_level,
        n_resamples=n_resamples,
        method="BCa",
        random_state=seed,
    )
    return {
        "n": int(arr.size),
        "mean": float(arr.mean()),
        "ci_low": float(result.confidence_interval.low),
        "ci_high": float(result.confidence_interval.high),
    }


def permutation_mean_difference(
    sample_a: Sequence[float],
    sample_b: Sequence[float],
    paired: bool = False,
    n_resamples: int = 9999,
    seed: int = 0,
) -> dict[str, float]:
    arr_a = np.asarray([value for value in sample_a if pd.notna(value)], dtype=float)
    arr_b = np.asarray([value for value in sample_b if pd.notna(value)], dtype=float)
    if arr_a.size == 0 or arr_b.size == 0:
        return {"delta_mean": np.nan, "pvalue": np.nan, "n_a": int(arr_a.size), "n_b": int(arr_b.size)}

    def statistic(a: np.ndarray, b: np.ndarray, axis: int = 0) -> np.ndarray:
        return np.mean(a, axis=axis) - np.mean(b, axis=axis)

    if paired and arr_a.size == arr_b.size:
        permutation_type = "samples"
    else:
        permutation_type = "independent"
        paired = False

    result = permutation_test(
        (arr_a, arr_b),
        statistic,
        permutation_type=permutation_type,
        n_resamples=n_resamples,
        alternative="two-sided",
        random_state=seed,
    )
    return {
        "delta_mean": float(arr_a.mean() - arr_b.mean()),
        "pvalue": float(result.pvalue),
        "n_a": int(arr_a.size),
        "n_b": int(arr_b.size),
        "paired": bool(paired),
    }


def pairwise_variant_table(
    df: pd.DataFrame,
    metric: str,
    variant_pairs: Sequence[tuple[str, str]],
    group_filter: Mapping[str, Any] | None = None,
    paired_on: Sequence[str] | None = None,
    n_resamples: int = 9999,
    seed: int = 0,
) -> pd.DataFrame:
    subset = df.copy()
    if group_filter:
        for key, value in group_filter.items():
            subset = subset[subset[key] == value]

    rows: list[dict[str, Any]] = []
    for left_variant, right_variant in variant_pairs:
        left = subset[subset["variant_id"] == left_variant].copy()
        right = subset[subset["variant_id"] == right_variant].copy()

        paired = False
        if paired_on:
            join_keys = list(paired_on)
            left = left[join_keys + [metric]].rename(columns={metric: f"{metric}_left"})
            right = right[join_keys + [metric]].rename(columns={metric: f"{metric}_right"})
            merged = left.merge(right, on=join_keys, how="inner")
            left_values = merged[f"{metric}_left"]
            right_values = merged[f"{metric}_right"]
            paired = not merged.empty
            n_effective = len(merged)
        else:
            left_values = left[metric]
            right_values = right[metric]
            n_effective = min(len(left), len(right))

        test = permutation_mean_difference(
            left_values,
            right_values,
            paired=paired,
            n_resamples=n_resamples,
            seed=seed,
        )
        rows.append(
            {
                "metric": metric,
                "left_variant": left_variant,
                "right_variant": right_variant,
                "delta_mean_left_minus_right": test["delta_mean"],
                "pvalue": test["pvalue"],
                "paired_test": test["paired"],
                "n_left": test["n_a"],
                "n_right": test["n_b"],
                "n_effective_pairs": n_effective,
            }
        )
    return pd.DataFrame(rows)


def spearman_screen(df: pd.DataFrame, target: str, feature_cols: Sequence[str]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for feature in feature_cols:
        subset = df[[target, feature]].dropna()
        if subset.empty or subset[feature].nunique() < 2 or subset[target].nunique() < 2:
            rows.append({"feature": feature, "n": len(subset), "rho": np.nan, "pvalue": np.nan})
            continue
        rho, pvalue = spearmanr(subset[feature], subset[target], nan_policy="omit")
        rows.append({"feature": feature, "n": len(subset), "rho": float(rho), "pvalue": float(pvalue)})
    out = pd.DataFrame(rows)
    return out.sort_values("rho", ascending=False, na_position="last").reset_index(drop=True)


def stage_metric_snapshot(
    aggregates_df: pd.DataFrame,
    metrics: Sequence[str],
    run_label: str | None = None,
) -> pd.DataFrame:
    subset = aggregates_df.copy()
    if run_label is not None:
        subset = subset[subset["run_label"] == run_label]
    keep = ["run_label", "stage", "variant_id", *metrics]
    keep = [column for column in keep if column in subset.columns]
    return subset[keep].sort_values(["run_label", "stage", "variant_id"]).reset_index(drop=True)


def choose_representative_review_packets(
    review_df: pd.DataFrame,
    variants: Sequence[str],
    sort_by: str = "power_retention_ratio",
    ascending: bool = True,
    top_k: int = 2,
) -> pd.DataFrame:
    subset = review_df[review_df["variant_id"].isin(variants)].copy()
    if subset.empty:
        return subset
    subset = subset.sort_values([sort_by, "summary_words"], ascending=[ascending, False])
    return subset.groupby("variant_id", group_keys=False).head(top_k).reset_index(drop=True)


def review_packet_for_llm(row: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "variant_id": row.get("variant_id"),
        "stage": row.get("stage"),
        "game_id": row.get("game_id"),
        "phase": row.get("phase"),
        "power": row.get("power"),
        "source_older_diary_text": row.get("source_older_diary_text"),
        "recent_retained_entries": row.get("recent_retained_entries"),
        "consolidated_summary_text": row.get("consolidated_summary_text"),
        "protocol_metrics": {
            "compression_ratio": row.get("compression_ratio"),
            "power_retention_ratio": row.get("power_retention_ratio"),
            "summary_words": row.get("summary_words"),
            "summary_status_tag_count": row.get("summary_status_tag_count"),
            "summary_heading_count": row.get("summary_heading_count"),
        },
    }


def openrouter_available() -> bool:
    return bool(os.getenv("OPENROUTER_API_KEY"))


def _extract_json_object(text: str) -> dict[str, Any]:
    text = str(text).strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text, flags=re.I).strip()
        text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    start = text.find("{")
    end = text.rfind("}")
    if start >= 0 and end > start:
        return json.loads(text[start : end + 1])
    raise ValueError(f"Could not parse JSON from model response:\n{text[:1200]}")


def call_openrouter_json(
    messages: Sequence[Mapping[str, str]],
    model: str = "openai/gpt-4.1-mini",
    temperature: float = 0.0,
    max_tokens: int = 1400,
    cache_dir: str | Path | None = None,
    use_cache: bool = True,
    timeout_seconds: int = 120,
) -> dict[str, Any]:
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        raise EnvironmentError("OPENROUTER_API_KEY is not set in the environment.")

    payload = {
        "model": model,
        "messages": list(messages),
        "temperature": temperature,
        "max_tokens": max_tokens,
        "response_format": {"type": "json_object"},
    }

    cache_path = None
    if cache_dir is not None:
        cache_dir = ensure_path(cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = cache_dir / f"{stable_hash(payload)}.json"
        if use_cache and cache_path.exists():
            return load_json(cache_path)

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-Title": "Memory Autoresearch Notebook",
    }
    with httpx.Client(timeout=timeout_seconds) as client:
        response = client.post(
            "https://openrouter.ai/api/v1/chat/completions",
            headers=headers,
            json=payload,
        )
        response.raise_for_status()
        body = response.json()

    content = body["choices"][0]["message"]["content"]
    parsed = _extract_json_object(content)

    if cache_path is not None:
        cache_path.write_text(json.dumps(parsed, indent=2, ensure_ascii=False), encoding="utf-8")
    return parsed


POINTWISE_MEMORY_REVIEW_PROMPT = """
You are a rigorous evaluator of Diplomacy memory summaries.

Judge the memory packet as a memory artifact, not as a final-game winner.
Focus on faithfulness to older diary content, strategic salience, actionability, freshness,
and formatting robustness.

Return JSON only.

Schema:
{
  "faithfulness_score": 1-5,
  "strategic_salience_score": 1-5,
  "actionability_score": 1-5,
  "freshness_score": 1-5,
  "formatting_robustness_score": 1-5,
  "main_strength": "short string",
  "main_failure_mode": "short string",
  "recommended_fix": "short string",
  "confidence": 0.0
}
"""


def llm_rate_review_packet(
    packet: Mapping[str, Any],
    model: str = "openai/gpt-4.1-mini",
    cache_dir: str | Path | None = None,
) -> dict[str, Any]:
    messages = [
        {"role": "system", "content": POINTWISE_MEMORY_REVIEW_PROMPT},
        {
            "role": "user",
            "content": json.dumps(packet, indent=2, ensure_ascii=False, default=str),
        },
    ]
    return call_openrouter_json(messages=messages, model=model, cache_dir=cache_dir)


PAIRWISE_MEMORY_COMPARISON_PROMPT = """
You are comparing two Diplomacy memory packets for memory quality.

Judge which packet is better as a compact strategic memory artifact.
Focus on:
1. faithfulness to the source older diary,
2. retention of strategically important actors, commitments, betrayals, and threats,
3. actionability for future planning,
4. freshness / control of stale content,
5. formatting robustness and clarity.

Return JSON only.

Schema:
{
  "winner": "A" | "B" | "tie",
  "faithfulness_winner": "A" | "B" | "tie",
  "salience_winner": "A" | "B" | "tie",
  "actionability_winner": "A" | "B" | "tie",
  "freshness_winner": "A" | "B" | "tie",
  "robustness_winner": "A" | "B" | "tie",
  "reason": "short string",
  "confidence": 0.0
}
"""


def llm_compare_review_packets(
    packet_a: Mapping[str, Any],
    packet_b: Mapping[str, Any],
    model: str = "openai/gpt-4.1-mini",
    cache_dir: str | Path | None = None,
    mirrored: bool = True,
) -> dict[str, Any]:
    def _single_compare(left_label: str, left_packet: Mapping[str, Any], right_label: str, right_packet: Mapping[str, Any]) -> dict[str, Any]:
        messages = [
            {"role": "system", "content": PAIRWISE_MEMORY_COMPARISON_PROMPT},
            {
                "role": "user",
                "content": json.dumps(
                    {
                        left_label: left_packet,
                        right_label: right_packet,
                    },
                    indent=2,
                    ensure_ascii=False,
                    default=str,
                ),
            },
        ]
        return call_openrouter_json(messages=messages, model=model, cache_dir=cache_dir)

    forward = _single_compare("A", packet_a, "B", packet_b)
    if not mirrored:
        return {"forward": forward}

    reverse = _single_compare("A", packet_b, "B", packet_a)

    def canonicalize(verdict: str, reversed_order: bool) -> str:
        verdict = str(verdict).strip().lower()
        if verdict == "tie":
            return "tie"
        if verdict not in {"a", "b"}:
            return "unknown"
        if not reversed_order:
            return verdict.upper()
        return "A" if verdict == "b" else "B"

    criteria = [
        "winner",
        "faithfulness_winner",
        "salience_winner",
        "actionability_winner",
        "freshness_winner",
        "robustness_winner",
    ]
    aggregate: dict[str, Any] = {"forward": forward, "reverse": reverse}
    for criterion in criteria:
        forward_canonical = canonicalize(forward.get(criterion, "unknown"), reversed_order=False)
        reverse_canonical = canonicalize(reverse.get(criterion, "unknown"), reversed_order=True)
        values = [forward_canonical, reverse_canonical]
        counts = pd.Series(values).value_counts().to_dict()
        aggregate[f"{criterion}_votes"] = counts
        if len(counts) == 1:
            aggregate[f"{criterion}_consensus"] = values[0]
        elif counts.get("A", 0) == counts.get("B", 0):
            aggregate[f"{criterion}_consensus"] = "tie"
        else:
            aggregate[f"{criterion}_consensus"] = max(counts, key=counts.get)
    return aggregate


def methodology_sources_frame() -> pd.DataFrame:
    return pd.DataFrame(QUALITATIVE_METHOD_SOURCES)
