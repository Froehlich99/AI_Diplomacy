# Cross-Model Four-Rotation Synthesis

Rows: 80

Per variant counts:
- V0_no_memory: 20
- V2_baseline_freeform: 20
- V3_structured_consolidation: 20
- V5_base: 20

Columns:
- rotation
- variant
- game
- power
- phase
- memory
- negotiation
- order
- actionability
- freshness
- memory_to_intent_consistency
- memory_update_quality

Notes:
- For V0_no_memory, the memory column is the literal string `<no consolidated memory injected in V0>` because no diary consolidation text is injected in that control condition.
- The negotiation column contains the exact raw `negotiation_diary` response text.
- The order column contains the exact submitted order list from `lmvsgame.json` serialized as JSON.
- The four analysis columns are qualitative judgments derived from the evidence text in the three evidence columns.
