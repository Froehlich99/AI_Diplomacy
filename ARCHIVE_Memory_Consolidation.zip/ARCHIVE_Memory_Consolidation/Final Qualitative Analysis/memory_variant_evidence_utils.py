from __future__ import annotations

import csv
import json
import re
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd

import memory_autoresearch as mr
import memory_autoresearch_notebook_utils as mau


FOCUS_VARIANTS = [
    "V0_no_memory",
    "V2_baseline_freeform",
    "V3_structured_consolidation",
    "V5_base",
]

PRIMARY_VARIANT_SOURCES = [
    {
        "variant_id": "V0_no_memory",
        "variant_label": "V0_no_memory",
        "run_label": "mem-v2",
        "run_root_name": "mem-v2",
        "cohort": "primary",
        "notes": "Authoritative control run for no-memory protocol.",
    },
    {
        "variant_id": "V2_baseline_freeform",
        "variant_label": "V2_baseline_freeform",
        "run_label": "mem-v2",
        "run_root_name": "mem-v2",
        "cohort": "primary",
        "notes": "Authoritative baseline freeform memory run.",
    },
    {
        "variant_id": "V3_structured_consolidation",
        "variant_label": "V3_structured_consolidation",
        "run_label": "mem-v2",
        "run_root_name": "mem-v2",
        "cohort": "primary",
        "notes": "Primary V3 comparator from the authoritative pre-V5 benchmark.",
    },
    {
        "variant_id": "V5_base",
        "variant_label": "V5_base",
        "run_label": "mem-v5-final",
        "run_root_name": "mem-v5-20260424__phase2_phase1_v5_03",
        "cohort": "primary",
        "notes": "Authoritative final V5 comparison run.",
    },
    {
        "variant_id": "V3_structured_consolidation",
        "variant_label": "V3_structured_consolidation [V5 anchor]",
        "run_label": "mem-v5-final",
        "run_root_name": "mem-v5-20260424__phase2_phase1_v5_03",
        "cohort": "anchor",
        "notes": "Anchor V3 from the same run family as V5_base to quantify run-family drift.",
    },
]


MEMORY_RESPONSE_TYPES = {
    "negotiation_diary",
    "phase_result_diary",
    "order_diary",
    "diary_consolidation",
}

PRIMARY_MEMORY_VARIANTS = {
    "V2_baseline_freeform",
    "V3_structured_consolidation",
    "V5_base",
}
ORDER_VERB_PATTERNS = {
    "support": re.compile(r"\bS\b|SUPPORT", re.IGNORECASE),
    "hold": re.compile(r"\bH\b|HOLD", re.IGNORECASE),
    "move": re.compile(r"\s-\s|MOVE", re.IGNORECASE),
    "convoy": re.compile(r"\bC\b|CONVOY", re.IGNORECASE),
    "build": re.compile(r"\bB\b|BUILD", re.IGNORECASE),
    "disband": re.compile(r"\bD\b|DISBAND|REMOVE", re.IGNORECASE),
}
PROVINCE_TOKEN_RE = re.compile(r"\b[A-Z]{3}(?:/[A-Z]{2})?\b")
NON_PROVINCE_ORDER_TOKENS = {
    "A",
    "F",
    "S",
    "C",
    "H",
    "B",
    "D",
    "VIA",
}


def build_focus_registry(root: str | Path) -> pd.DataFrame:
    root = Path(root)
    results_root = root / "results" / "autoresearch"
    rows: list[dict[str, Any]] = []
    for item in PRIMARY_VARIANT_SOURCES:
        run_root = results_root / item["run_root_name"]
        if not run_root.exists():
            continue
        rows.append(
            {
                **item,
                "run_root": run_root,
            }
        )
    return pd.DataFrame(rows)


def _iter_variant_game_dirs(run_root: Path, variant_id: str) -> Iterable[tuple[str, str, Path]]:
    for game_dir in sorted(run_root.glob(f"*/{variant_id}/game_*")):
        rel = game_dir.relative_to(run_root).parts
        if len(rel) != 3:
            continue
        stage_name, _, game_key = rel
        yield stage_name, game_key, game_dir


def _extract_final_supply_centers(saved_game: Mapping[str, Any]) -> dict[str, float]:
    phases = saved_game.get("phases", []) or []
    if not phases:
        return {power: 0.0 for power in mr.ALL_POWERS}
    centers = (phases[-1].get("state", {}) or {}).get("centers", {}) or {}
    return {power: float(len(centers.get(power, []) or [])) for power in mr.ALL_POWERS}


def _mutual_friendly_edges(state_agents: Mapping[str, Any]) -> set[tuple[str, str]]:
    edges: set[tuple[str, str]] = set()
    for power, agent_state in state_agents.items():
        relationships = agent_state.get("relationships", {}) or {}
        for other_power, relation in relationships.items():
            if power >= other_power:
                continue
            if str(relation).strip().lower() != "friendly":
                continue
            other_relationships = (state_agents.get(other_power, {}) or {}).get("relationships", {}) or {}
            if str(other_relationships.get(power, "")).strip().lower() == "friendly":
                edges.add((power, other_power))
    return edges


def _top_trust_partners(state_agents: Mapping[str, Any]) -> dict[str, str]:
    output: dict[str, str] = {}
    for power, agent_state in state_agents.items():
        trust_scores = agent_state.get("trust_scores", {}) or {}
        candidates = [
            (float(score), other_power)
            for other_power, score in trust_scores.items()
            if isinstance(score, (int, float))
        ]
        if not candidates:
            continue
        candidates.sort(key=lambda item: (-item[0], item[1]))
        output[power] = candidates[0][1]
    return output


def _friendly_sets(state_agents: Mapping[str, Any]) -> dict[str, set[str]]:
    output: dict[str, set[str]] = {}
    for power, agent_state in state_agents.items():
        relationships = agent_state.get("relationships", {}) or {}
        output[power] = {
            other_power
            for other_power, relation in relationships.items()
            if str(relation).strip().lower() == "friendly"
        }
    return output


def _jaccard_ratio(left: set[Any], right: set[Any]) -> float:
    union = left | right
    if not union:
        return np.nan
    return len(left & right) / len(union)


def compute_downstream_correlates(saved_game: Mapping[str, Any]) -> dict[str, Any]:
    final_counts = _extract_final_supply_centers(saved_game)
    counts = [float(final_counts.get(power, 0.0)) for power in mr.ALL_POWERS]
    total = sum(counts)
    sorted_counts = sorted(counts, reverse=True)

    phase_states = [
        phase_block.get("state_agents", {}) or {}
        for phase_block in saved_game.get("phases", [])
        if phase_block.get("state_agents")
    ]
    mutual_edge_jaccards: list[float] = []
    top_trust_stability_flags: list[float] = []
    friendly_set_jaccards: list[float] = []

    for previous_state, current_state in zip(phase_states, phase_states[1:]):
        previous_edges = _mutual_friendly_edges(previous_state)
        current_edges = _mutual_friendly_edges(current_state)
        edge_jaccard = _jaccard_ratio(previous_edges, current_edges)
        if pd.notna(edge_jaccard):
            mutual_edge_jaccards.append(edge_jaccard)

        previous_top = _top_trust_partners(previous_state)
        current_top = _top_trust_partners(current_state)
        for power in set(previous_top) & set(current_top):
            top_trust_stability_flags.append(float(previous_top[power] == current_top[power]))

        previous_friendly = _friendly_sets(previous_state)
        current_friendly = _friendly_sets(current_state)
        for power in set(previous_friendly) & set(current_friendly):
            ratio = _jaccard_ratio(previous_friendly[power], current_friendly[power])
            if pd.notna(ratio):
                friendly_set_jaccards.append(ratio)

    return {
        "survivors": int(sum(1 for count in counts if count > 0)),
        "eliminations": int(sum(1 for count in counts if count <= 0)),
        "concentration_hhi": float(sum((count / total) ** 2 for count in counts)) if total > 0 else np.nan,
        "leader_share": float(sorted_counts[0] / total) if total > 0 and sorted_counts else np.nan,
        "top2_share": float(sum(sorted_counts[:2]) / total) if total > 0 else np.nan,
        "final_sc_std": float(np.std(counts)) if counts else np.nan,
        "mutual_alliance_edge_continuity": float(np.mean(mutual_edge_jaccards)) if mutual_edge_jaccards else np.nan,
        "top_trust_partner_stability": float(np.mean(top_trust_stability_flags)) if top_trust_stability_flags else np.nan,
        "friendly_set_continuity": float(np.mean(friendly_set_jaccards)) if friendly_set_jaccards else np.nan,
    }


def _parse_json_object(raw_text: str) -> dict[str, Any]:
    if not raw_text:
        return {}
    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError:
        return {}
    return parsed if isinstance(parsed, dict) else {}


def _phase_orders_lookup(saved_game: Mapping[str, Any]) -> dict[tuple[str, str], list[str]]:
    lookup: dict[tuple[str, str], list[str]] = {}
    for phase_block in saved_game.get("phases", []) or []:
        phase_name = str(phase_block.get("name", "")).strip()
        orders = phase_block.get("orders", {}) or {}
        for power, order_list in orders.items():
            normalized = [str(order).strip() for order in order_list or [] if str(order).strip()]
            lookup[(phase_name, power)] = normalized
    return lookup


def _negotiation_diary_lookup(game_dir: Path) -> dict[tuple[str, str], dict[str, Any]]:
    lookup: dict[tuple[str, str], dict[str, Any]] = {}
    llm_path = game_dir / "llm_responses.csv"
    if not llm_path.exists():
        return lookup
    with llm_path.open("r", encoding="utf-8", newline="") as handle:
        for row in csv.DictReader(handle):
            if row.get("response_type") != "negotiation_diary":
                continue
            payload = _parse_json_object(row.get("raw_response", ""))
            key = (str(row.get("phase", "")).strip(), str(row.get("power", "")).strip())
            lookup[key] = payload
    return lookup


def _keyword_signal(text: str, keywords: list[str]) -> float:
    return float(mr.keyword_present(text, keywords))


def _keyword_grounding(memory_text: str, downstream_text: str, keywords: list[str]) -> float:
    if not mr.keyword_present(downstream_text, keywords):
        return np.nan
    return float(mr.keyword_present(memory_text, keywords))


def _extract_province_tokens(text: str) -> set[str]:
    tokens = {
        token
        for token in PROVINCE_TOKEN_RE.findall((text or "").upper())
        if token not in NON_PROVINCE_ORDER_TOKENS
        and token not in mr.ALL_POWERS
        and token not in {"ENG", "RUS", "GER", "FRA", "ITA", "AUS", "TUR"}
    }
    return tokens


def _order_verbs(order_strings: list[str]) -> set[str]:
    joined = " | ".join(order_strings)
    matched = {
        verb
        for verb, pattern in ORDER_VERB_PATTERNS.items()
        if pattern.search(joined)
    }
    return matched


def _text_verbs(text: str) -> set[str]:
    matched = {
        verb
        for verb, pattern in ORDER_VERB_PATTERNS.items()
        if pattern.search(text or "")
    }
    return matched


def _nanmean(values: list[float]) -> float:
    usable = [float(value) for value in values if pd.notna(value)]
    return float(np.mean(usable)) if usable else np.nan


def _safe_overlap(left: set[str], right: set[str], denominator: set[str]) -> float:
    if not denominator:
        return np.nan
    return len(left & right) / len(denominator)


def load_memory_pathway_evidence(registry: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for item in registry.to_dict(orient="records"):
        if item["variant_id"] not in PRIMARY_MEMORY_VARIANTS:
            continue
        run_root = Path(item["run_root"])
        for stage_name, game_key, game_dir in _iter_variant_game_dirs(run_root, item["variant_id"]):
            saved_game = mau.load_json(game_dir / "lmvsgame.json")
            negotiation_lookup = _negotiation_diary_lookup(game_dir)
            orders_lookup = _phase_orders_lookup(saved_game)
            for sample in mr._extract_consolidation_samples(saved_game):
                phase = str(sample.get("phase", "")).strip()
                power = str(sample.get("power", "")).strip()
                source_text = sample.get("source_older_diary_text", "") or ""
                summary_text = sample.get("summary_text", "") or ""
                recent_entries = list(sample.get("recent_retained_entries", []) or [])
                recent_text = "\n\n".join(recent_entries).strip()

                diary_payload = negotiation_lookup.get((phase, power), {})
                intent_text = str(diary_payload.get("intent", "") or "").strip()
                negotiation_summary_text = str(diary_payload.get("negotiation_summary", "") or "").strip()
                orders = orders_lookup.get((phase, power), [])
                orders_text = " | ".join(orders)

                source_powers = set(mr.iter_named_powers(source_text))
                summary_powers = set(mr.iter_named_powers(summary_text))
                recent_powers = set(mr.iter_named_powers(recent_text))
                intent_powers = set(mr.iter_named_powers(intent_text))
                order_tokens = _extract_province_tokens(orders_text)
                intent_tokens = _extract_province_tokens(intent_text)
                order_verbs = _order_verbs(orders)
                intent_verbs = _text_verbs(intent_text)

                actionability_actor_score = min(len(summary_powers), 3) / 3 if summary_powers else 0.0
                actionability_commitment = _keyword_signal(summary_text, mr.COMMITMENT_KEYWORDS)
                actionability_threat = _keyword_signal(summary_text, mr.THREAT_KEYWORDS)
                actionability_goal = _keyword_signal(summary_text, mr.GOAL_KEYWORDS)
                actionability_proxy = _nanmean(
                    [
                        actionability_actor_score,
                        actionability_commitment,
                        actionability_threat,
                        actionability_goal,
                    ]
                )

                summary_to_intent_power_recall = _safe_overlap(summary_powers, intent_powers, intent_powers)
                summary_to_intent_commitment_grounding = _keyword_grounding(
                    summary_text, intent_text, mr.COMMITMENT_KEYWORDS
                )
                summary_to_intent_threat_grounding = _keyword_grounding(
                    summary_text, intent_text, mr.THREAT_KEYWORDS
                )
                summary_to_intent_goal_grounding = _keyword_grounding(
                    summary_text, intent_text, mr.GOAL_KEYWORDS
                )
                memory_to_intent_proxy = _nanmean(
                    [
                        summary_to_intent_power_recall,
                        summary_to_intent_commitment_grounding,
                        summary_to_intent_threat_grounding,
                        summary_to_intent_goal_grounding,
                    ]
                )

                intent_to_order_target_alignment = _safe_overlap(intent_tokens, order_tokens, order_tokens)
                intent_to_order_verb_alignment = _safe_overlap(intent_verbs, order_verbs, order_verbs)
                memory_to_order_proxy = _nanmean(
                    [
                        memory_to_intent_proxy,
                        intent_to_order_target_alignment,
                        intent_to_order_verb_alignment,
                    ]
                )

                stale_actor_ratio = _safe_overlap(summary_powers - (recent_powers | intent_powers), summary_powers, summary_powers)
                if pd.notna(stale_actor_ratio):
                    stale_actor_ratio = 1.0 - stale_actor_ratio

                rows.append(
                    {
                        "run_label": item["run_label"],
                        "variant_id": item["variant_id"],
                        "variant_label": item["variant_label"],
                        "cohort": item["cohort"],
                        "stage": stage_name,
                        "game_key": game_key,
                        "game_dir": str(game_dir),
                        "phase": phase,
                        "power": power,
                        "source_older_diary_text": source_text,
                        "summary_text": summary_text,
                        "recent_retained_entries": recent_entries,
                        "recent_text": recent_text,
                        "next_negotiation_summary": negotiation_summary_text,
                        "next_intent": intent_text,
                        "submitted_orders": orders,
                        "submitted_orders_text": orders_text,
                        "source_power_count": len(source_powers),
                        "summary_power_count": len(summary_powers),
                        "intent_power_count": len(intent_powers),
                        "summary_recent_power_overlap": _safe_overlap(summary_powers, recent_powers, summary_powers),
                        "actionability_actor_score": actionability_actor_score,
                        "actionability_commitment_signal": actionability_commitment,
                        "actionability_threat_signal": actionability_threat,
                        "actionability_goal_signal": actionability_goal,
                        "actionability_proxy": actionability_proxy,
                        "summary_to_intent_power_recall": summary_to_intent_power_recall,
                        "summary_to_intent_commitment_grounding": summary_to_intent_commitment_grounding,
                        "summary_to_intent_threat_grounding": summary_to_intent_threat_grounding,
                        "summary_to_intent_goal_grounding": summary_to_intent_goal_grounding,
                        "memory_to_intent_proxy": memory_to_intent_proxy,
                        "intent_to_order_target_alignment": intent_to_order_target_alignment,
                        "intent_to_order_verb_alignment": intent_to_order_verb_alignment,
                        "memory_to_order_proxy": memory_to_order_proxy,
                        "freshness_nonstale_actor_ratio": stale_actor_ratio,
                    }
                )
    return pd.DataFrame(rows)


def random_sample_rows(
    df: pd.DataFrame,
    group_col: str,
    n_per_group: int = 3,
    random_state: int = 42,
) -> pd.DataFrame:
    if df.empty:
        return df
    parts: list[pd.DataFrame] = []
    for _, group in df.groupby(group_col, dropna=False):
        take = min(n_per_group, len(group))
        parts.append(group.sample(n=take, random_state=random_state))
    return pd.concat(parts, ignore_index=True).sort_values([group_col]).reset_index(drop=True)


def load_focus_game_metrics(registry: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for item in registry.to_dict(orient="records"):
        run_root = Path(item["run_root"])
        for stage_name, game_key, game_dir in _iter_variant_game_dirs(run_root, item["variant_id"]):
            metrics = mr.collect_game_metrics(game_dir)
            saved_game = mau.load_json(game_dir / "lmvsgame.json")
            downstream = compute_downstream_correlates(saved_game)
            rows.append(
                {
                    "run_label": item["run_label"],
                    "variant_id": item["variant_id"],
                    "variant_label": item["variant_label"],
                    "cohort": item["cohort"],
                    "stage": stage_name,
                    "game_key": game_key,
                    "game_dir": str(game_dir),
                    **{key: value for key, value in metrics.items() if key != "consolidation_samples"},
                    **downstream,
                    "consolidation_sample_count": len(metrics.get("consolidation_samples", [])),
                }
            )
    return pd.DataFrame(rows)


def summarize_metrics(
    df: pd.DataFrame,
    metrics: list[str],
    group_cols: list[str] | None = None,
) -> pd.DataFrame:
    group_cols = group_cols or ["variant_label", "stage"]
    rows: list[dict[str, Any]] = []
    for keys, group in df.groupby(group_cols, dropna=False):
        if not isinstance(keys, tuple):
            keys = (keys,)
        row = {column: value for column, value in zip(group_cols, keys)}
        row["n_games"] = len(group)
        for metric in metrics:
            row[f"{metric}_mean"] = group[metric].mean()
            row[f"{metric}_median"] = group[metric].median()
        rows.append(row)
    return pd.DataFrame(rows).sort_values(group_cols).reset_index(drop=True)


def load_focus_stage_aggregates(registry: pd.DataFrame) -> pd.DataFrame:
    run_registry = pd.DataFrame(
        [
            {"run_label": item["run_label"], "run_root": item["run_root"]}
            for item in registry.to_dict(orient="records")
        ]
    ).drop_duplicates()
    aggregates_df, _ = mau.load_run_registry_stage_tables(run_registry)
    if aggregates_df.empty:
        return aggregates_df

    enriched = aggregates_df.merge(
        registry[["run_label", "variant_id", "variant_label", "cohort"]].drop_duplicates(),
        on=["run_label", "variant_id"],
        how="inner",
    )
    return enriched.sort_values(["cohort", "variant_label", "stage"]).reset_index(drop=True)


def load_memory_failures(registry: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for item in registry.to_dict(orient="records"):
        run_root = Path(item["run_root"])
        for stage_name, game_key, game_dir in _iter_variant_game_dirs(run_root, item["variant_id"]):
            llm_path = game_dir / "llm_responses.csv"
            if not llm_path.exists():
                continue
            with llm_path.open("r", encoding="utf-8", newline="") as handle:
                for row in csv.DictReader(handle):
                    if row.get("response_type") not in MEMORY_RESPONSE_TYPES:
                        continue
                    if not mr._memory_row_is_failure(row):
                        continue
                    rows.append(
                        {
                            "run_label": item["run_label"],
                            "variant_id": item["variant_id"],
                            "variant_label": item["variant_label"],
                            "cohort": item["cohort"],
                            "stage": stage_name,
                            "game_key": game_key,
                            "power": row.get("power"),
                            "phase": row.get("phase"),
                            "response_type": row.get("response_type"),
                            "success": row.get("success"),
                            "raw_response_preview": (row.get("raw_response") or "")[:300],
                        }
                    )
    return pd.DataFrame(rows)


def load_invalid_order_evidence(registry: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for item in registry.to_dict(orient="records"):
        run_root = Path(item["run_root"])
        for stage_name, game_key, game_dir in _iter_variant_game_dirs(run_root, item["variant_id"]):
            saved_game = mau.load_json(game_dir / "lmvsgame.json")
            for phase_block in saved_game.get("phases", []):
                phase_name = phase_block.get("name")
                order_results = phase_block.get("order_results", {}) or {}
                for power, type_map in order_results.items():
                    if not isinstance(type_map, Mapping):
                        continue
                    for order_type, entries in type_map.items():
                        for payload in entries or []:
                            if not isinstance(payload, Mapping):
                                continue
                            result = str(payload.get("result", "")).strip().lower()
                            if result != "invalid":
                                continue
                            rows.append(
                                {
                                    "run_label": item["run_label"],
                                    "variant_id": item["variant_id"],
                                    "variant_label": item["variant_label"],
                                    "cohort": item["cohort"],
                                    "stage": stage_name,
                                    "game_key": game_key,
                                    "phase": phase_name,
                                    "power": power,
                                    "order_type": order_type,
                                    "order": payload.get("order"),
                                    "result": result,
                                    "details": json.dumps(payload, ensure_ascii=False),
                                }
                            )
    return pd.DataFrame(rows)


def load_consolidation_evidence(registry: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for item in registry.to_dict(orient="records"):
        run_root = Path(item["run_root"])
        for stage_name, game_key, game_dir in _iter_variant_game_dirs(run_root, item["variant_id"]):
            saved_game = mau.load_json(game_dir / "lmvsgame.json")
            for sample in mr._extract_consolidation_samples(saved_game):
                source_text = sample.get("source_older_diary_text", "") or ""
                summary_text = sample.get("summary_text", "") or ""
                rows.append(
                    {
                        "run_label": item["run_label"],
                        "variant_id": item["variant_id"],
                        "variant_label": item["variant_label"],
                        "cohort": item["cohort"],
                        "stage": stage_name,
                        "game_key": game_key,
                        "phase": sample.get("phase"),
                        "power": sample.get("power"),
                        "source_words": mau.word_count(source_text),
                        "summary_words": mau.word_count(summary_text),
                        "retention_score": mr.automatic_retention_score(source_text, summary_text),
                        "source_older_diary_text": source_text,
                        "summary_text": summary_text,
                        "recent_retained_entries": sample.get("recent_retained_entries", []),
                    }
                )
    return pd.DataFrame(rows)


def load_log_evidence(registry: pd.DataFrame) -> pd.DataFrame:
    run_registry = pd.DataFrame(
        [
            {"run_label": item["run_label"], "run_root": item["run_root"]}
            for item in registry.to_dict(orient="records")
        ]
    ).drop_duplicates()
    log_df = mau.load_run_registry_logs(run_registry)
    if log_df.empty:
        return log_df
    return log_df.merge(
        registry[["run_label", "variant_id", "variant_label", "cohort"]].drop_duplicates(),
        on=["run_label", "variant_id"],
        how="inner",
    )


def representative_rows(
    df: pd.DataFrame,
    group_col: str,
    sort_col: str,
    ascending: bool = False,
    n_per_group: int = 3,
) -> pd.DataFrame:
    if df.empty:
        return df
    subset = df.sort_values([group_col, sort_col], ascending=[True, ascending])
    return subset.groupby(group_col, group_keys=False).head(n_per_group).reset_index(drop=True)
