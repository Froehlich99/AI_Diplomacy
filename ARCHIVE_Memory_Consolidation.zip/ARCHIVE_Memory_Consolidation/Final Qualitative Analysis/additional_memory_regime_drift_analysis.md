# Additional Memory-Regime Drift Analysis

This note extends the focused evidence notebook with extra analysis of:

- actionability of the summary,
- memory-to-intent consistency,
- memory-to-order pathway,
- freshness / stale-memory control,
- qualitative update quality.

The reproducible tables and plots live in [analysis/memory_variant_evidence.ipynb](/Users/anatolelobenko/Downloads/AI_Diplomacy-main/analysis/memory_variant_evidence.ipynb). The notebook was regenerated from [analysis/build_memory_variant_evidence_notebook.py](/Users/anatolelobenko/Downloads/AI_Diplomacy-main/analysis/build_memory_variant_evidence_notebook.py) and executed after adding the new loaders in [analysis/memory_variant_evidence_utils.py](/Users/anatolelobenko/Downloads/AI_Diplomacy-main/analysis/memory_variant_evidence_utils.py).

## Automated proxies

All automated metrics are computed on real consolidation packets in the `cross_model` slice and aligned to:

1. the same-phase consolidated summary,
2. the same-phase `negotiation_diary.intent`,
3. the submitted order list in `lmvsgame.json`.

The main proxies are:

- `actionability_proxy`
  Mean of:
  - actor coverage in the summary, clipped at 3 named powers,
  - commitment signal present,
  - threat signal present,
  - goal signal present.
- `memory_to_intent_proxy`
  Mean of:
  - intent power recall from the summary,
  - commitment grounding,
  - threat grounding,
  - goal grounding.
- `memory_to_order_proxy`
  Mean of:
  - `memory_to_intent_proxy`,
  - intent-to-order province-token overlap,
  - intent-to-order verb overlap.
- `freshness_nonstale_actor_ratio`
  Share of summary actors that are also supported by either the recent retained diary window or the next intent.

These are intentionally transparent proxies, not hidden learned scores.

## Cross-model results

Cross-model means from the executed notebook:

| Variant | Actionability | Memory->Intent | Intent->Order Targets | Intent->Order Verbs | Memory->Order | Freshness |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| `V2_baseline_freeform` | 0.9973 | 0.9917 | 0.9543 | 0.7163 | 0.8875 | 0.8943 |
| `V3_structured_consolidation` | 1.0000 | 0.9790 | 0.9564 | 0.7437 | 0.8930 | 0.8919 |
| `V5_base` | 1.0000 | 0.9986 | 0.9574 | 0.7024 | 0.8861 | 0.9124 |

### Evidence-based interpretation

- Actionability is at ceiling for all three memory regimes. Once the summary exists at all, all variants usually preserve named actors plus commitment/threat/goal language.
- `V5` is strongest on `memory_to_intent_proxy` and freshness. Its tagged structure tends to carry the right actors and diplomatic status labels directly into the next plan.
- `V3` is slightly weaker on `memory_to_intent_proxy` but best on intent-to-order verb alignment. In practice, its structure often makes the operative action language especially easy to translate into concrete orders.
- `V2` is competitive on memory-to-intent consistency, but its freeform style more often accumulates historical narrative around the current plan.
- The composite `memory_to_order_proxy` is very close across all three (`0.886-0.893`). That means most regime differences show up in what the memory looks like, not in a dramatic collapse of downstream operational usability.

## Drift patterns by regime

### V2 freeform

Strengths:

- Semantically rich, often narrates betrayals and strategic pivots in a way that remains usable for the next intent.
- Very strong memory-to-intent grounding despite minimal structure.

Drift pattern:

- Tends to accumulate long historical arcs and carry background actors forward.
- Lower freshness often reflects narrative inertia rather than outright factual error.
- Low-end memory-to-order cases usually come from downstream execution slippage, not from the summary failing to name the right commitments.

Representative cases:

- `game_01 / S1905M / ENGLAND`
  The summary is highly actionable: Germany is recast as the key betrayer, France and the western theatre are live, and the intent directly follows that frame. The main drift is overload. The summary mixes a long 1901-1904 chronology with the current reclaim-`NTH` plan, and the submitted orders only partially match the stated intent (`A WAL-BRE` becomes `A WAL-LON`; `F STP/NC-BOT` becomes a hold).
- `game_01 / S1908M / ENGLAND`
  Strong actionability and update quality. The summary keeps the important regime shifts: Germany's stab, the `AUS/TUR` north split, and the anti-France coordination with Italy. Freshness is only moderate because the memory still carries a lot of older alliance texture that is no longer central to the immediate order set.
- `game_02 / S1903M / GERMANY`
  This is a strong freeform success case. England is explicitly downgraded from ally to rival, Russia stays useful but cautious, and the plan to grab `PAR` while forcing `SWE` follows directly from the summary. Here the freeform style does not drift; it remains sharp and current.

### V3 structured consolidation

Strengths:

- Best order-verb alignment.
- Commitments, betrayals, goals, and threats are easy to read and often map almost one-to-one into the next intent.

Drift pattern:

- The schema can preserve a broader actor set than the next move really needs.
- It is especially prone to keeping neutral or "irrelevant" powers around as explicit bullets, which helps coverage but not always freshness.

Representative cases:

- `game_01 / S1905M / ENGLAND`
  This is the cleanest summary-to-intent-to-order pathway among the sampled packets. The summary's "Open Commitments" section maps directly into the next plan and then into the submitted orders. The only real drift is mild freshness loss from retaining `Italy/Austria/Turkey` as explicit neutral or irrelevant actors.
- `game_01 / S1907M / RUSSIA`
  Excellent update quality. The summary tracks broken `GER` and `ENG` relationships, preserves the `FR` bloc, and turns that into an aggressive anti-Germany plan. The only caution is that it keeps a large self-history of failed `STP/SC` holds, which is useful context but also a sign of narrative fixation.
- `game_02 / S1902M / TURKEY`
  Mixed case. The summary correctly updates Austria from an unreliable opener to a real anti-Russia partner and keeps the operative anti-Russia goals. But freshness is weaker because the summary still preserves a broader actor set than the next move needs, and the intent/orders chain partially drifts: the intent describes a support-heavy `RUM-SEV` style line while the actual orders pivot toward `BUL-RUM`.

### V5 tagged structure

Strengths:

- Strongest freshness on average.
- Best explicit update semantics through `[confirmed]`, `[broken]`, `[tentative]`, and `[stale]` distinctions.
- Very strong memory-to-intent grounding.

Drift pattern:

- Some low-end freshness scores are metric artifacts: V5 often keeps stale material on purpose but labels it `[stale]` rather than deleting it.
- Its order-verb alignment is slightly weaker than V3 because the structured plan can remain semantically correct while the final orders still simplify or re-route tactics.

Representative cases:

- `game_01 / S1907M / RUSSIA`
  Strong update quality. The summary cleanly separates active agreements from broken ones and carries the right threats into the plan. The final orders diverge on some specifics, but the drift is operational rather than mnemonic: the memory is clearly steering the plan even when exact tactical execution shifts.
- `game_02 / S1903M / TURKEY`
  Excellent freshness and actionability. The summary preserves the right live coalition (`Italy`), marks the repeated `Russia` failures as broken, and translates directly into an anti-Austria / anti-Russia intent. This is the best sampled example of V5's status-tag format helping the next move.
- `game_02 / S1908M / GERMANY`
  Very strong memory artifact. It keeps only a few active commitments, clearly labels older betrayals, and frames the immediate west-focused locking plan. This is a good example of V5 compressing a long history without losing the operative diplomatic edges.

## Freshness caveat

The lowest freshness proxy values should not be read naively as "worst memory."

Examples:

- `V5 / game_02 / S1904M / AUSTRIA` scores poorly on freshness because the summary keeps a Turkey de-escalation line marked `[stale]`, even though the immediate plan is dominated by the France anti-Italy coalition.
- `V5 / game_02 / S1905M / TURKEY` also scores poorly because the summary still names Austria, Russia, and Italy on the watchlist. That is a legitimate compression choice when those actors are still strategically relevant.
- `V2 / game_02 / S1904M / TURKEY` is stale for a different reason: it re-narrates the whole 1901-1903 alliance arc in freeform prose instead of trimming down to the live Moscow campaign.

So the freshness proxy is useful for spotting accumulation, but low scores in `V5` often reflect explicit stale tagging rather than blind drift.

## Bottom line

- All three memory regimes are highly usable for next-phase planning once a summary is produced.
- `V2` is the most narratively rich but also the most prone to historical accumulation.
- `V3` is the clearest for translating commitments into concrete tactical language, but its schema can over-preserve actors.
- `V5` shows the best explicit update hygiene and strongest average freshness, with the caveat that its stale-tagging behavior can look worse to a simple actor-overlap proxy than it really is.

The net conclusion is that the biggest regime differences are about *how* memory drifts, not whether memory becomes unusable. `V2` drifts toward narrative accumulation, `V3` toward schema-preserved breadth, and `V5` toward explicit status-tagged carryover.
